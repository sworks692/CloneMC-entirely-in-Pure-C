# Water overlay + Java-style water flow patch

This patch keeps the recent menu, hand, inventory, and crafting fixes, then adds back only the water screen overlay and adds a budgeted Java-inspired water flow update.

## Added back
- `DrawWaterOverlay2D()` now runs during `DrawSurvivalUI()` before hearts, oxygen bubbles, and hotbar, so the HUD remains visible above the overlay.
- The overlay uses `assets/beta/water.tga` and a light blue tint, with reduced darkening so it does not hide the GUI or blocks too much.
- The overlay is visual only; it does not force the old full-screen dark water system back into the menu or inventory layers.

## Water physics / flow
- Added `UpdateJavaStyleWaterFlow(double dt)`.
- Water now updates on a small timed budget around the player for Win98/Open Watcom performance.
- Water falls downward first, then spreads sideways when supported, matching the basic Java liquid priority idea.
- Horizontal spread is limited around sea level and capped per tick so oceans/caves do not flood the whole finite world at once.
- The player water movement logic remains: water slows horizontal movement, damps vertical speed, and Space swims upward.

## OpenGL state safety
- The overlay resets blend/color/depth state afterward so it should not tint the menu, inventory, terrain, or mobs.

## Compile command
```bat
wcl386 -bt=nt -l=nt_win -fe=clonemc.exe project1new.c opengl32.lib glu32.lib gdi32.lib user32.lib winmm.lib
```
