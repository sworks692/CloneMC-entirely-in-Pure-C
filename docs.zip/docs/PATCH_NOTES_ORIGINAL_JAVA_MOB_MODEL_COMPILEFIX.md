# Original Java mob model + Open Watcom compile fix

Focus of this patch:

- Kept the newer A* / pathfinding and advanced mob behavior logic in `project1new.c`.
- Kept the Java-style render pipeline, but stabilized the livestock models so pig, cow, and chicken use the original Java model box sizes and rotation points from:
  - `ModelQuadruped.java`
  - `ModelPig.java`
  - `ModelCow.java`
  - `ModelChicken.java`
  - `ModelRenderer.java`
  - `RenderPig.java`
  - `RenderCow.java`
  - `RenderChicken.java`
- Fixed the Open Watcom errors around lines 13895-13924 by baking Java local constants like `byte0 = 16` and `i = 15` into literal float coordinates before the `JavaModelPart` struct initializers.
- Kept the texture/music ZIP mob textures as the source atlas for `assets/mobs/pig.tga`, `cow.tga`, and `chicken.tga`.
- Added a GL color reset after textured mob box rendering to prevent green/tint state from leaking into later block or mob draws.
- Adjusted chicken wing animation to follow Java `RenderChicken.getWingRotation()` style more closely.

Important behavior note:

The pathfinding/AI code was not removed. This patch only changes model definitions/rendering and the Open Watcom compile issue caused by non-literal aggregate initializers.

Compile command:

```bat
wcl386 -bt=nt -l=nt_win -fe=clonemc.exe project1new.c opengl32.lib glu32.lib gdi32.lib user32.lib winmm.lib
```
