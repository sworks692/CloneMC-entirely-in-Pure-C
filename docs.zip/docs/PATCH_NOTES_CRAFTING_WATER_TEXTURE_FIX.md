# PATCH_CRAFTING_WATER_TEXTURE_FIX

This patch focuses on the problems reported in the latest test build:

1. **Crafting table and inventory crafting glitching**
   - Reworked recipe matching to behave more like Java `CraftingManager`, `ShapedRecipes`, and `ShapelessRecipes`.
   - Shaped recipes can now match in different positions inside the grid instead of only the upper-left corner.
   - Mirrored shaped recipes are also accepted, like Java's shaped recipe matching.
   - The 2x2 inventory crafting grid and the 3x3 workbench grid are separated more cleanly.
   - Workbench GUI slot picking now uses the exact `gui/crafting.png` slot coordinates instead of relying on the normal inventory helper.
   - Clicking outside the GUI still drops the carried stack into the world.

2. **Old/custom water behavior cleanup**
   - Disabled the full-screen water darkening/overlay pass.
   - Removed the strong custom buoyancy/surface push behavior.
   - Replaced it with a small Java-style water drag/jump impulse so water slows the player without the previous odd surface/bobbing behavior.
   - Oxygen bubbles and drowning counters still work.

3. **Green overlay / wrong block hues**
   - Disabled the previous biome tint multiplier that caused some blocks to look too green.
   - Terrain now renders with neutral white texture color so the TGA/PNG atlas colors show directly.
   - Reset GL color after the durability bar so green UI drawing cannot leak into later draw calls.

Only one C source file is included: `project1new.c`. The `assets/` and `docs/` folders are included for the matching runtime textures and notes.
