# Open Watcom screen/spawn compile fix

This pass fixes the Open Watcom errors reported from `project1newscreen.c`.

## Fixed

- Moved local variable declarations above the `#if CLONEMC_USE_JAVA_WORLD_ITEM_PORT` early-return branches in:
  - `GetToolMiningSpeed()`
  - `GetBetaBiomeAt()`
  - `BetaDensity3D()`
  - `BetaTerrainHeight()`
  - `AddWorldFeatures()`
  - `AddOrePass()`
- Added the missing `IsSkyVisibleAt()` prototype.
- Added an `IsSkyVisibleAt()` implementation used by safe-spawn and ore-sunlight checks.
- Kept the spawn-near-0,0 behavior and Java-style death screen from the previous patch.

## Why the Open Watcom errors happened

Open Watcom was seeing a `return` inside a preprocessor branch before local variable declarations. That made the following declarations appear outside a valid function block, causing the misleading `Missing '}'`, `item has not been declared`, `temp already initialized`, and similar errors.

## Compile

Use the NT Win32 link target:

```bat
wcl386 -bt=nt -l=nt_win -fe=clonemc.exe project1new.c opengl32.lib glu32.lib gdi32.lib user32.lib winmm.lib
```

Do not use plain `-l=win`, because Open Watcom reports `undefined system name: win` in your environment.
