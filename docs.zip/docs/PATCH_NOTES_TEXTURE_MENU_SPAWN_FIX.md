# Texture, menu, and mob-spawn cleanup patch

This patch focuses on three reported problems:

1. **Wrong block/item colors or wrong atlas tiles** — normal block rendering now uses `GetVerifiedBlockTile()` before falling back to Java texture indices. This keeps the uploaded 512x256 terrain atlas coordinates stable for the blocks currently used by terrain, drops, hotbar block icons, and crafting outputs. The Java item atlas table is kept for `assets/beta/items.tga`.
2. **Main menus glitching** — the menu background now uses the verified dirt tile from `terrain.tga` by default, and image/UI drawing resets GL color back to white after drawing. This prevents stale green/dark UI state from leaking into menus or terrain.
3. **Mob spawn rate slightly too low** — caps increased gently from 12 mobs total to 16 total, passive/hostile caps from 3 to 4, and spawn attempts from 1 to 2. Pathfinding/render distances were not increased, so this should not heavily affect performance.

Search in `project1new.c` for:

```c
PATCH_TEXTURE_MENU_SPAWN_VERIFY
GetVerifiedBlockTile
```

To swap a block texture, edit the centralized `TILE_*_COL` and `TILE_*_ROW` values at the top of the file or add/modify a case in `GetVerifiedBlockTile()`.
