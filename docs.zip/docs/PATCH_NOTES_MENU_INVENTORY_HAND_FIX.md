# Menu / Inventory / Crafting / Held Item Fix

This package keeps the existing world, mob, pathfinding, texture, and lighting work, and focuses only on the GUI/crafting/held-item issues.

## Fixed

- Main menu/world/options/pause screens now reset OpenGL GUI state before drawing, reducing texture/color/state glitches when switching screens.
- Removed extra explanatory note text from GUI screens; screens now show only core titles/buttons/fields.
- Menu background now uses the verified dirt tile from terrain texture instead of the glitch-prone imported background texture.
- Inventory and workbench slot hover frames make the clickable slot squares clear without adding text notes.
- 2x2 inventory crafting and 3x3 crafting table clicking use consistent drag/drop logic.
- Recipe matching now supports Java-style shaped recipe offsets and mirrored recipes instead of only matching upper-left recipes.
- Result slot updates after every slot move/drop/right-click.
- Dragging outside the inventory/crafting GUI throws the carried stack into the world, matching the requested behavior.
- First-person held blocks/items are larger and positioned to cover most of the player hand instead of floating beside it.
- Removed the full-screen water overlay from the survival HUD path so old/simple water behavior stays active.

## Source contents

Only one C source file is included: `project1new.c`.  Assets and docs are included for reference/runtime use.
