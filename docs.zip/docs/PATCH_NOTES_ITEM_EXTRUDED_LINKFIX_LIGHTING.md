# Item extruded renderer link fix + blocky lighting safeguard

This patch fixes the Open Watcom linker error:

```text
Error! E2028: DrawJavaItemExtrudedQuadLocal_ is an undefined reference
```

## Code changes in `project1new.c`

- Added the missing `DrawJavaItemExtrudedQuadLocal(int item, float size, int full3D)` function.
- The function renders Java-style extruded item cards for held items, dropped items, tools, sticks, bones, bows, and other full-3D inventory items.
- Front/back/edge faces use fixed blocky face shades instead of smooth lighting, closer to Java/Beta item rendering.
- The function resets `glColor4f(1,1,1,1)` after drawing so item shading does not leak into terrain blocks, GUI, mobs, or the hotbar.
- The existing block and terrain lighting code was kept intact:
  - `ComputeLegacyLighting()`
  - `RecomputeLegacyLightingLocal()`
  - per-face cube shading in dropped/world block rendering
  - torch/block-light updates

## Build note

The warning below is caused by the linker system name in the compile command, not by C code:

```text
Warning! W1107: undefined system name: win
```

Use `-l=nt_win` instead of `-l=win`.
