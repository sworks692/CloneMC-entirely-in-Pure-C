# Java files used as references for this patch

Crafting / recipe behavior:
- `CraftingManager.java` — central recipe registration and recipe lookup behavior.
- `ShapedRecipes.java` — shaped recipe grid matching, including offset and mirrored layout behavior.
- `ShapelessRecipes.java` — shapeless ingredient matching behavior.
- `RecipesCrafting.java`, `RecipesTools.java`, `RecipesWeapons.java`, `RecipesIngots.java`, `RecipesFood.java`, `RecipesArmor.java`, `RecipesDyes.java` — recipe families used as reference coverage.
- `ContainerWorkbench.java` — 3x3 workbench matrix and result slot behavior.
- `ContainerPlayer.java` — 2x2 player inventory crafting matrix behavior.
- `InventoryCrafting.java`, `InventoryCraftResult.java`, `SlotCrafting.java`, `ItemStack.java` — crafting inventory/result stack behavior.
- `GuiCrafting.java`, `GuiInventory.java` — GUI texture and slot-coordinate references.

Water / texture-color behavior:
- `BlockFluid.java`, `BlockFlowing.java`, `BlockStationary.java` — water/lava block interaction reference.
- `Entity.java`, `EntityLiving.java`, `EntityPlayer.java` — water movement, air timer, and drowning behavior reference.
- `ColorizerGrass.java`, `ColorizerFoliage.java`, `ColorizerWater.java` — colorizer reference; disabled in this C patch until exact colorizer atlas blending is stable.
- `RenderBlocks.java` and `Tessellator.java` — block vertex color/texture drawing reference.

Texture folders used:
- `gui/crafting.png`
- `gui/inventory.png`
- `gui/gui.png`
- `gui/icons.png`
- `gui/items.png`
- `terrain.png`
- `misc/water.png`
