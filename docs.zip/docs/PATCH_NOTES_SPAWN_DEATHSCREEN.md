# CloneMC spawn/death-screen patch

This pass focuses on the two requested gameplay fixes:

1. **World spawn centered around global X/Z 0,0**
   - `FindSafeSpawn()` now delegates to `FindSafeSpawnAroundGlobalZero()`.
   - The preferred spawn center is computed as `GlobalToLocalBlockX(0)` and `GlobalToLocalBlockZ(0)`, then clamped into the currently loaded world window.
   - The same safe Y rule remains active: `PLAYER_SPAWN_MIN_Y` through `PLAYER_SPAWN_MAX_Y`, currently Y 20-50.
   - If a natural safe spot cannot be found, `ForceSpawnPad()` creates a small safe grass/dirt/cobblestone pad at the global 0,0 area.

2. **Java-style death screen instead of instant auto-respawn**
   - Added `STATE_DEATH`.
   - `TakeDamage()` now sets health to 0 and calls `EnterDeathScreen()` when all hearts are lost.
   - Gameplay input stops and the mouse is released.
   - The world remains visible behind a dark red/black game-over overlay.
   - The player must choose **Respawn**, press **Enter/Space**, or choose **Title screen**.
   - Respawn uses the global 0,0 safe-spawn code and restores health, timers, air, camera wobble, and movement state.

## Java references used

The behavior was matched to the uploaded Java source structure:

- `GuiGameOver.java`
  - `initGui()` adds `Respawn` and `Title menu` buttons.
  - `actionPerformed()` respawns the player or returns to main menu.
  - `drawScreen()` draws a dark red/black gradient and the `Game over!` title.

- `EntityPlayerSP.java`
  - `respawnPlayer()` calls the client respawn path.

- `GuiIngame.java`
  - Heart health remains based on the existing HUD system already ported into the C project.

## Source packaging note

This zip includes assets/docs for running and review, but only one edited C source file:

- `project1new.c`
