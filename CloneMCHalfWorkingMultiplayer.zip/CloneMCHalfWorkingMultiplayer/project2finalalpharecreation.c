/*
    CloneMC V80 Multiplayer Entity Interaction Build
    ------------------------------------------------------------
    Current unity source for Open Watcom.  Keep this one-translation-unit
    build: the section files intentionally share globals and old-C prototypes.

    V80 focus:
      - Priority 2 multiplayer entity, inventory, and interaction sync.
      - Java NetClientHandler-style remote players/mobs/item drops.
      - Packet21/22 item spawn/collect handling.
      - Packet28/38 velocity/status handling.
      - Packet100/101/103/104/105/106 window and slot sync.
      - Server-authoritative block break/place/attack behavior in multiplayer.
      - Keeps V79 terrain-cache and join stability work.
*/

/* CORE / TYPES / GLOBALS / PROTOTYPES */
#include "src/00_core/clonemc_core_defs.c"

/* NETWORK / BETA 1.7.3 + CLASSIC/CLASSICUBE MULTIPLAYER CLIENT PROTOCOL */
#include "src/NETWORK/clonemc_network_beta173.c"

/* SAVE / TILE ENTITIES / REGION / NBT-LIKE PERSISTENCE */
#include "src/10_save/clonemc_save_tile_region.c"

/* ENTITY / MOB AI CORE / PATHING / LIVING COLLISION HELPERS */
#include "src/20_entity/clonemc_entity_mob_ai_core.c"

/* ITEM / RECIPES / CONTAINERS / REDSTONE / FEATURE SYSTEMS */
#include "src/30_item/clonemc_items_containers_redstone.c"

/* ENTITY / DROPPED ITEMS / HELD ITEMS / PLAYER PHYSICS */
#include "src/20_entity/clonemc_entity_items_player_physics.c"

/* LIGHTING / V48 QUEUE FRONT-END */
#include "src/50_lighting/clonemc_lighting_v48_front.c"

/* UI / PLATFORM / OPENGL STARTUP / TEXTURES / MENUS / LEGACY SAVE UI */
#include "src/60_ui/clonemc_platform_ui_resources.c"

/* WORLD / GENERATION / STREAMING / PARTICLES / DROPPED ITEM WORLD LOOP */
#include "src/40_world/clonemc_world_generation_streaming.c"

/* ENTITY / MOB MODELS / PLAYER CONTROL / CAMERA / WORLD ENTRY RENDER CALL */
#include "src/20_entity/clonemc_entity_mob_render_player.c"

/* RENDER / BLOCK RENDER TYPES / RENDERBLOCKS-STYLE GEOMETRY */
#include "src/70_render/clonemc_render_block_types.c"

/* LIGHTING / EMISSION / PROPAGATION / FACE BRIGHTNESS */
#include "src/50_lighting/clonemc_lighting_brightness_render.c"

/* ITEM / COMBAT / ITEM USE / SPECIAL ENTITY UPDATE */
#include "src/30_item/clonemc_item_combat_special_entities.c"

/* RENDER / CHUNK QUEUES / SPECIAL ENTITIES / FIRST-PERSON ITEMS */
#include "src/70_render/clonemc_render_chunks_special_entities.c"

/* ITEM + UI / SURVIVAL INVENTORY / CRAFTING / HUD TAIL */
#include "src/30_item/clonemc_inventory_crafting_ui_tail.c"

/* WORLD / JAVA-STYLE SCHEDULED BLOCK TICK QUEUE */
#include "src/40_world/clonemc_scheduled_ticks_v52.c"
