/*
    CloneMC V80 src/NETWORK/clonemc_network_beta173.c
    ------------------------------------------------------------
    Open Watcom/Win32 friendly Minecraft Beta 1.7.3 + Classic/ClassiCube protocol layer.
    V65 keeps this file under src/NETWORK, uses WinSock2, adds old Open Watcom header fallbacks, and fixes text/zlib loading.

    Java source files used as direct implementation reference:
      GuiMultiplayer.java, GuiConnecting.java, ThreadConnectToServer.java,
      NetworkManager.java, Packet.java, NetClientHandler.java,
      EntityClientPlayerMP.java, Packet0/1/2/3/4/6/8/9/10/11/12/13/14/15/16/18,
      Packet20/21/22/24/28/29/30/31/32/33/34/38/40,
      Packet50/51/52/53, Packet100/101/103/104/105/106/255.

    ClassiCube reference used for defensive network shape only, not for protocol:
      non-blocking connect/read tick, fixed read buffers, packet size validation,
      timeout handling, and bounded send retry pattern.

    Notes:
      - Uses WinSock2 API and ws2_32.lib. It still avoids getaddrinfo/IPv6-only calls so Windows 98 era builds remain realistic.
      - V62 adds a real username field. Server address/IP is never reused as the username, never copied into chat, and is hidden from the connecting screen.
      - Optional zlib1.dll or zlib.dll is loaded dynamically for Packet51 map chunks.
        If a real zlib DLL is not present, CloneMC still connects and exchanges
        login/chat/position/block-change packets, but full remote terrain chunks
        are safely skipped instead of overflowing buffers.
*/

#ifndef INVALID_SOCKET
#define INVALID_SOCKET (SOCKET)(~0)
#endif
#ifndef SOCKET_ERROR
#define SOCKET_ERROR (-1)
#endif

#define NETV60_PROTOCOL_VERSION 14
#define NETV60_DEFAULT_PORT 25565
#define NETV60_READ_BUFFER_SIZE 524288
#define NETV60_SEND_BUFFER_SIZE 2048
#define NETV60_STATUS_SIZE 256
#define NETV60_MAX_PACKET_CHUNK 262144L
#define NETV60_MAX_DECOMPRESSED_CHUNK 196608L
#define NETV60_MAX_STRING_CHARS 32767
#define NETV60_CONNECT_TIMEOUT 15.0
#define NETV60_READ_TIMEOUT 30.0
#define NETV60_POSITION_INTERVAL 0.05
#define NETV61_MAX_CHAT_CHARS 119
#define NETV61_CHAT_MIN_INTERVAL 0.30
#define NETV61_CHAT_BURST_WINDOW 5.0
#define NETV61_CHAT_BURST_LIMIT 10
#define NETV61_MAX_PACKETS_PER_TICK 128
#define NETV61_MAX_BYTES_PER_TICK 524288L
#define NETV76_MAX_CHUNK_PACKETS_PER_TICK 4
#define NETV76_MAX_RECV_LOOPS_PER_TICK 8
#define NETV77_JOIN_HOLD_MAX_SECONDS 12.0
#define NETV77_JOIN_HOLD_RELEASE_AFTER_CHUNKS 2
#define NETV78_JOIN_SOFT_RELEASE_SECONDS 3.0
#define NETV78_JOIN_HARD_RELEASE_SECONDS 8.0
#define NETV78_JOIN_NO_TERRAIN_FAIL_SECONDS 10.0
#define NETV79_MISSING_TERRAIN_COLLISION_SECONDS 6.0
#define NETV79_CENTER_CHUNK_RELEASE_SECONDS 1.25
#define NETV79_NETWORK_JOIN_CHUNK_BUDGET_WIN98 2
#define NETV79_NETWORK_JOIN_CHUNK_BUDGET_WIN10 4
#define NETV80_WINDOW_SLOTS 128
#define NETV80_REMOTE_DROPPED_ITEM_SLOTS MAX_DROPPED_ITEMS
#define NETV80_REMOTE_NAME_CHARS 16
#define NETV61_MAX_HOST_CHARS 120
#define NETV61_MAX_ABS_COORD 30000000L
#define NETV61_MAX_SERVER_CORRECTION 4096.0
#define NETV61_SOCKET_RECV_TIMEOUT_MS 30000
#define NETV61_SOCKET_SEND_TIMEOUT_MS 10000
#define NETV62_PROTOCOL_BETA173 0
#define NETV62_PROTOCOL_CLASSICUBE 1
#define NETV62_MAX_USERNAME_CHARS 16
#define NETV62_MIN_USERNAME_CHARS 3
#define NETV62_CLASSIC_STRING_CHARS 64
#define NETV62_CLASSIC_LEVEL_CHUNK 1024
#define NETV62_CLASSIC_MAX_COMPRESSED_LEVEL 2097152L
#define NETV62_CLASSIC_MAX_LEVEL_OUT (4L + ((long)WORLD_X * (long)WORLD_Y * (long)WORLD_Z))
#define NETV62_CLASSIC_DEFAULT_PORT 25565
#define NETV62_Z_FINISH 4
#define NETV62_Z_STREAM_END 1
#ifndef SD_BOTH
#define SD_BOTH 2
#endif
#ifndef TCP_NODELAY
#define TCP_NODELAY 0x0001
#endif

/*
    Open Watcom's bundled WinSock2 headers can miss IP_TOS on some installs,
    especially when targeting older Win32/Windows 98 compatible builds.
    The real WinSock value is 3, but the option is best-effort only; failure
    is intentionally ignored by NetV61_ConfigureSocket().
*/
#ifndef IP_TOS
#define IP_TOS 3
#endif
#ifndef IPPROTO_IP
#define IPPROTO_IP 0
#endif
#ifndef SO_RCVTIMEO
#define SO_RCVTIMEO 0x1006
#endif
#ifndef SO_SNDTIMEO
#define SO_SNDTIMEO 0x1005
#endif

typedef int (__cdecl *NetV60_ZlibUncompressProc)(unsigned char *dest, unsigned long *destLen, const unsigned char *source, unsigned long sourceLen);

typedef struct NetV62_ZStream_s {
    unsigned char *next_in;
    unsigned int avail_in;
    unsigned long total_in;
    unsigned char *next_out;
    unsigned int avail_out;
    unsigned long total_out;
    char *msg;
    void *state;
    void *zalloc;
    void *zfree;
    void *opaque;
    int data_type;
    unsigned long adler;
    unsigned long reserved;
} NetV62_ZStream;

typedef const char *(__cdecl *NetV62_ZlibVersionProc)(void);
typedef int (__cdecl *NetV62_ZlibInflateInit2Proc)(NetV62_ZStream *strm, int windowBits, const char *version, int stream_size);
typedef int (__cdecl *NetV62_ZlibInflateProc)(NetV62_ZStream *strm, int flush);
typedef int (__cdecl *NetV62_ZlibInflateEndProc)(NetV62_ZStream *strm);

static int g_netV60WinsockReady = 0;
static int g_netV60State = 0; /* 0 idle, 1 connecting, 2 connected, 3 failed */
static SOCKET g_netV60Socket = INVALID_SOCKET;
static char g_netV60Host[128] = "localhost";
static int g_netV60Port = NETV60_DEFAULT_PORT;
static char g_netV60Status[NETV60_STATUS_SIZE] = "Network idle.";
static unsigned char g_netV60ReadBuffer[NETV60_READ_BUFFER_SIZE];
static unsigned char g_netV60ChunkOut[NETV60_MAX_DECOMPRESSED_CHUNK];
static int g_netV60ReadLen = 0;
static double g_netV60ConnectTime = 0.0;
static double g_netV60LastReadTime = 0.0;
static double g_netV60PositionTimer = 0.0;
static double g_netV60TimeNow = 0.0;
static int g_netV60EntityId = -1;
static int g_netV60Dimension = 0;
static int g_netV60SawLogin = 0;
static int g_netV60MissingZlibWarned = 0;
static int g_netV60TerrainChunksApplied = 0;
static int g_netV60TerrainChunksSkipped = 0;
static int g_netV69RemoteBatchApply = 0;
static int g_netV76ChunkPacketsThisTick = 0;
static int g_netV76DeferredPostDirty = 0;
static int g_netV76DeferredMinX = WORLD_X;
static int g_netV76DeferredMinZ = WORLD_Z;
static int g_netV76DeferredMaxX = -1;
static int g_netV76DeferredMaxZ = -1;
static int g_netV76ServerLightAccepted = 0;
static int g_netV76ServerLightMissing = 0;
static unsigned char g_netV77RemoteChunkData[WORLD_CHUNKS_X][WORLD_CHUNKS_Z];
/* V79: Java WorldClient/ChunkProviderClient-style multiplayer chunk cache state. */
static unsigned char g_netV79RemoteChunkPrepared[WORLD_CHUNKS_X][WORLD_CHUNKS_Z];
static unsigned char g_netV79RemoteChunkCollisionReady[WORLD_CHUNKS_X][WORLD_CHUNKS_Z];
static int g_netV79PreparedChunksThisJoin = 0;
static int g_netV79CollisionChunksThisJoin = 0;
static int g_netV79JoinReleasedForTerrain = 0;
static double g_netV79LastTerrainChunkTime = 0.0;
static int g_netV77JoinHoldActive = 0;
static int g_netV77SawServerPosition = 0;
static int g_netV77SawSpawnPacket = 0;
static int g_netV77JoinSafeAnnounced = 0;
static int g_netV77ChunksDataThisJoin = 0;
static double g_netV77JoinHoldStartTime = 0.0;
static double g_netV77LastServerGX = 0.0;
static double g_netV77LastServerGY = 0.0;
static double g_netV77LastServerGZ = 0.0;
static int g_netV78JoinReleasedByTimeout = 0;
static int g_netV78JoinCenterReadyOnce = 0;
static double g_netV60OldX = 999999.0;
static double g_netV60OldY = 999999.0;
static double g_netV60OldStance = 999999.0;
static double g_netV60OldZ = 999999.0;
static float g_netV60OldYaw = 999999.0f;
static float g_netV60OldPitch = 999999.0f;
static int g_netV60OldGround = -1;
static HMODULE g_netV60ZlibModule = NULL;
static NetV60_ZlibUncompressProc g_netV60Uncompress = NULL;
static int g_netV60TriedZlib = 0;
static char g_netV65ZlibDllName[32] = "";
static double g_netV61LastChatTime = -9999.0;
static double g_netV61ChatWindowStart = 0.0;
static int g_netV61ChatBurstCount = 0;
static double g_netV61LastSendTime = 0.0;
static long g_netV61BytesThisTick = 0L;
static int g_netV61PacketsThisTick = 0;
static int g_netV61SecurityDisconnects = 0;
static int g_netV62ProtocolMode = NETV62_PROTOCOL_BETA173;
static char g_netV62Username[NETV62_MAX_USERNAME_CHARS + 1] = "Player";
static char g_netV62ClassicKey[NETV62_CLASSIC_STRING_CHARS + 1] = "";
static unsigned char g_netV62ClassicCompressed[NETV62_CLASSIC_MAX_COMPRESSED_LEVEL];
static unsigned char g_netV62ClassicLevelOut[NETV62_CLASSIC_MAX_LEVEL_OUT];
static long g_netV62ClassicCompressedLen = 0L;
static int g_netV62ClassicLevelX = 0;
static int g_netV62ClassicLevelY = 0;
static int g_netV62ClassicLevelZ = 0;
static int g_netV62ClassicServerOp = 0;
static int g_netV62ClassicCpeEntriesLeft = 0;
static NetV62_ZlibVersionProc g_netV62ZlibVersion = NULL;
static NetV62_ZlibInflateInit2Proc g_netV62InflateInit2 = NULL;
static NetV62_ZlibInflateProc g_netV62Inflate = NULL;
static NetV62_ZlibInflateEndProc g_netV62InflateEnd = NULL;

#define NETV71_REMOTE_ENTITY_SLOTS MAX_MOBS
static int g_netV71RemoteEntityIds[NETV71_REMOTE_ENTITY_SLOTS];
static int g_netV71RemoteEntityIsPlayer[NETV71_REMOTE_ENTITY_SLOTS];
/* V80: Java NetClientHandler/WorldClient runtime entity and inventory state.
   The C renderer still uses the bounded Mob/DroppedItem arrays, but packet
   state is now server-authoritative instead of being consumed and ignored. */
static char g_netV80RemoteEntityName[NETV71_REMOTE_ENTITY_SLOTS][NETV80_REMOTE_NAME_CHARS + 1];
static int g_netV80RemoteEntityHeldItem[NETV71_REMOTE_ENTITY_SLOTS];
static int g_netV80RemoteEntityHeldDamage[NETV71_REMOTE_ENTITY_SLOTS];
static int g_netV80RemoteDroppedItemEntityIds[NETV80_REMOTE_DROPPED_ITEM_SLOTS];
static int g_netV80RemoteDroppedItemIndex[NETV80_REMOTE_DROPPED_ITEM_SLOTS];
static int g_netV80OpenWindowId = -1;
static int g_netV80OpenWindowType = 0;
static int g_netV80OpenWindowSlotCount = 0;
static char g_netV80OpenWindowTitle[128] = "";
static InventorySlot g_netV80WindowSlots[NETV80_WINDOW_SLOTS];
static InventorySlot g_netV80CursorStack;
static short g_netV80LastTransactionAction = 0;

int g_networkMultiplayerActive = 0;

/* V69: C89 forward declarations for helpers used before their definitions.
   Open Watcom does not allow C99-style implicit/static mismatches here. */
void WorldGenV70_ClearWorldArraysNoTerrain(void);
static void NetV68_EnsureWindowForGlobal(double gx, double gz);
static void NetV68_FinishRemoteChunkApply(void);
static void NetV70_PrepareRemoteClientWorld(void);
static void NetV77_ResetRemoteChunkDataFlags(void);
static void NetV77_MarkRemoteChunkDataGlobalChunk(int chunkX, int chunkZ, int hasData);
static void NetV79_PrepareRemoteChunkGlobal(int chunkX, int chunkZ);
static void NetV79_EnsureWindowForIncomingTerrain(int blockX, int blockZ);
static int NetV79_LocalChunkTerrainReady(int cx, int cz);
static void NetV71_DestroyRemoteEntity(long entityId);
static void NetV77_BeginJoinHold(void);
static void NetV77_CheckJoinHoldRelease(void);
static void NetV60_WriteU8(unsigned char *buf, int *off, int v);
static void NetV60_WriteU16(unsigned char *buf, int *off, int v);
static void NetV60_WriteU32(unsigned char *buf, int *off, long v);
int NetworkV77_ShouldHoldPlayerDuringJoin(void);
int NetworkV78_ShouldHoldPlayerDuringJoin(void);
int NetworkV79_IsLocalBlockInLoadedServerChunk(int x, int y, int z);
int NetworkV79_ShouldTreatMissingTerrainAsSolid(int x, int y, int z, double testFeetY);
void NetworkV80_SendUseEntity(int targetEntityId, int leftClick);
void NetworkV80_SendEntityAction(int actionState);
void NetworkV80_SendWindowClick(int windowId, int slot, int mouseButton, int actionNumber, int shiftClick);

static void NetV60_SetStatus(const char *text)
{
    if (!text) { text = "Network status unavailable."; }
    strncpy(g_netV60Status, text, sizeof(g_netV60Status) - 1);
    g_netV60Status[sizeof(g_netV60Status) - 1] = 0;
    strncpy(g_guiV9StatusMessage, g_netV60Status, sizeof(g_guiV9StatusMessage) - 1);
    g_guiV9StatusMessage[sizeof(g_guiV9StatusMessage) - 1] = 0;
}

static double NetV60_TimeSeconds(void);

/* V75_PACKET_TRACE: tiny Win98-safe packet trace.
   Create an empty file named net_trace_enable.txt beside the EXE to enable it.
   The trace is intentionally simple stdio so Open Watcom/Win98 builds do not
   need modern logging libraries. */
static int g_netV75TraceChecked = 0;
static int g_netV75TraceEnabled = 0;

static void NetV75_TracePacket(const char *dir, int op, const char *name, int consumed, int available)
{
    FILE *f;
    if (!g_netV75TraceChecked) {
        f = fopen("net_trace_enable.txt", "rb");
        if (f) { g_netV75TraceEnabled = 1; fclose(f); }
        g_netV75TraceChecked = 1;
    }
    if (!g_netV75TraceEnabled) { return; }
    f = fopen("net_trace.txt", "a");
    if (!f) { return; }
    fprintf(f, "%.3f %s id=%d name=%s consumed=%d available=%d state=%d readLen=%d\n",
            NetV60_TimeSeconds(), dir ? dir : "IN", op, name ? name : "?",
            consumed, available, g_netV60State, g_netV60ReadLen);
    fclose(f);
}

static const char *NetV75_PacketName(int op)
{
    switch (op) {
    case 0: return "KeepAlive";
    case 1: return "Login";
    case 2: return "Handshake";
    case 3: return "Chat";
    case 4: return "UpdateTime";
    case 5: return "PlayerInventory";
    case 6: return "SpawnPosition";
    case 8: return "UpdateHealth";
    case 9: return "Respawn";
    case 10: return "Flying";
    case 11: return "PlayerPosition";
    case 12: return "PlayerLook";
    case 13: return "PlayerLookMove";
    case 16: return "HeldItemChange";
    case 17: return "Sleep";
    case 18: return "Animation";
    case 20: return "NamedEntitySpawn";
    case 21: return "PickupSpawn";
    case 22: return "Collect";
    case 23: return "VehicleSpawn";
    case 24: return "MobSpawn";
    case 25: return "EntityPainting";
    case 28: return "EntityVelocity";
    case 29: return "DestroyEntity";
    case 30: return "Entity";
    case 31: return "RelEntityMove";
    case 32: return "EntityLook";
    case 33: return "RelEntityMoveLook";
    case 34: return "EntityTeleport";
    case 38: return "EntityStatus";
    case 39: return "AttachEntity";
    case 40: return "EntityMetadata";
    case 50: return "PreChunk";
    case 51: return "MapChunk";
    case 52: return "MultiBlockChange";
    case 53: return "BlockChange";
    case 54: return "PlayNoteBlock";
    case 60: return "Explosion";
    case 61: return "DoorChange";
    case 70: return "Bed";
    case 71: return "Weather";
    case 100: return "OpenWindow";
    case 101: return "CloseWindow";
    case 103: return "SetSlot";
    case 104: return "WindowItems";
    case 105: return "UpdateProgressbar";
    case 106: return "Transaction";
    case 130: return "UpdateSign";
    case 131: return "MapData";
    case 200: return "Statistic";
    case 201: return "PlayerListItem";
    case 250: return "PluginMessage";
    case 255: return "KickDisconnect";
    }
    return "Unknown";
}

static double NetV60_TimeSeconds(void)
{
    return (double)GetTickCount() / 1000.0;
}

static void NetV60_Trim(char *s);
static int NetV62Classic_HandlePacket(const unsigned char *buf, int len, int *consumed);
static int NetV62Classic_SendMessage(const char *message);
static int NetV62Classic_SendSetBlock(int gx, int gy, int gz, int create, int block);
static void NetV62_SendInitialHandshake(void);

static int NetV62_LooksLikeAddress(const char *s)
{
    int hasDotOrColon;
    int i;
    if (!s) { return 0; }
    hasDotOrColon = 0;
    for (i = 0; s[i]; i++) {
        if (s[i] == '.' || s[i] == ':' || s[i] == '/' || s[i] == '\\' || s[i] == '@') { hasDotOrColon = 1; break; }
    }
    return hasDotOrColon;
}

static int NetV62_IsUsernameChar(unsigned char c)
{
    if (c >= '0' && c <= '9') { return 1; }
    if (c >= 'A' && c <= 'Z') { return 1; }
    if (c >= 'a' && c <= 'z') { return 1; }
    if (c == '_') { return 1; }
    return 0;
}

static int NetV62_SanitizeUsername(const char *in, char *out, int outSize)
{
    int i;
    int w;
    unsigned char c;
    if (!out || outSize <= 1) { return 0; }
    out[0] = 0;
    if (!in || !in[0] || NetV62_LooksLikeAddress(in)) {
        strncpy(out, "Player", outSize - 1);
        out[outSize - 1] = 0;
        return 1;
    }
    w = 0;
    for (i = 0; in[i] && w < outSize - 1 && w < NETV62_MAX_USERNAME_CHARS; i++) {
        c = (unsigned char)in[i];
        if (NetV62_IsUsernameChar(c)) { out[w++] = (char)c; }
    }
    out[w] = 0;
    if (w < NETV62_MIN_USERNAME_CHARS) {
        strncpy(out, "Player", outSize - 1);
        out[outSize - 1] = 0;
    }
    return 1;
}

int NetworkV62_SetUsername(const char *name)
{
    char clean[NETV62_MAX_USERNAME_CHARS + 1];
    if (!NetV62_SanitizeUsername(name, clean, sizeof(clean))) { return 0; }
    strncpy(g_netV62Username, clean, sizeof(g_netV62Username) - 1);
    g_netV62Username[sizeof(g_netV62Username) - 1] = 0;
    return 1;
}

const char *NetworkV62_GetUsername(void)
{
    if (!g_netV62Username[0]) { NetworkV62_SetUsername("Player"); }
    return g_netV62Username;
}

void NetworkV62_SetProtocolMode(int mode)
{
    if (mode != NETV62_PROTOCOL_CLASSICUBE) { mode = NETV62_PROTOCOL_BETA173; }
    g_netV62ProtocolMode = mode;
}

void NetworkV62_ToggleProtocolMode(void)
{
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_BETA173) { g_netV62ProtocolMode = NETV62_PROTOCOL_CLASSICUBE; }
    else { g_netV62ProtocolMode = NETV62_PROTOCOL_BETA173; }
}

int NetworkV62_GetProtocolMode(void)
{
    return g_netV62ProtocolMode;
}

const char *NetworkV62_GetProtocolName(void)
{
    return g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE ? "ClassiCube / Classic" : "Minecraft Beta 1.7.3";
}


static int NetV61_IsSafeAsciiForChat(unsigned char c)
{
    if (c >= 32 && c <= 126) { return 1; }
    return 0;
}

static int NetV65_IsMinecraftColorCode(unsigned char c)
{
    if (c >= '0' && c <= '9') { return 1; }
    if (c >= 'a' && c <= 'f') { return 1; }
    if (c >= 'A' && c <= 'F') { return 1; }
    if (c == 'k' || c == 'K' || c == 'l' || c == 'L' || c == 'm' || c == 'M' ||
        c == 'n' || c == 'N' || c == 'o' || c == 'O' || c == 'r' || c == 'R') { return 1; }
    return 0;
}

static void NetV61_SanitizeDisplayText(char *s)
{
    int r;
    int w;
    unsigned char c;
    int lastSpace;
    if (!s) { return; }
    r = 0;
    w = 0;
    lastSpace = 1;
    while (s[r] && w < 250) {
        c = (unsigned char)s[r++];
        /* Java FontRenderer consumes Minecraft formatting codes.  If the C
           fallback font renders the raw bytes, server names/chat become ?a,
           random symbols, or unreadable prefixes.  Strip both Beta Unicode
           section-sign codes and Classic &-codes before display. */
        if (c == 0xA7 || (c == '&' && NetV65_IsMinecraftColorCode((unsigned char)s[r]))) {
            if (s[r]) { r++; }
            continue;
        }
        if (c == '\r' || c == '\n' || c == '\t') { c = ' '; }
        if (NetV61_IsSafeAsciiForChat(c)) {
            if (c == ' ') {
                if (!lastSpace) { s[w++] = ' '; lastSpace = 1; }
            } else {
                s[w++] = (char)c;
                lastSpace = 0;
            }
        }
    }
    while (w > 0 && s[w - 1] == ' ') { w--; }
    s[w] = 0;
}

static int NetV61_EqualsIgnoreCasePrefix(const char *s, const char *prefix)
{
    int i;
    unsigned char a;
    unsigned char b;
    if (!s || !prefix) { return 0; }
    for (i = 0; prefix[i]; i++) {
        if (!s[i]) { return 0; }
        a = (unsigned char)s[i];
        b = (unsigned char)prefix[i];
        if (a >= 'A' && a <= 'Z') { a = (unsigned char)(a + 32); }
        if (b >= 'A' && b <= 'Z') { b = (unsigned char)(b + 32); }
        if (a != b) { return 0; }
    }
    return 1;
}

static int NetV61_IsDangerousLocalChatCommand(const char *s)
{
    if (!s) { return 0; }
    while (*s == ' ' || *s == '\t') { s++; }
    if (!s[0]) { return 0; }
    /* CloneMC never executes local shell commands from chat. These checks also
       block common accidental command-execution prefixes used by launchers/tools. */
    if (s[0] == '!' || s[0] == '`') { return 1; }
    if (s[0] == '/' && (s[1] == '/' || s[1] == '\\')) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "cmd:")) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "powershell:")) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "file:")) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "shell:")) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "run:")) { return 1; }
    if (NetV61_EqualsIgnoreCasePrefix(s, "exec:")) { return 1; }
    return 0;
}

static int NetV61_SanitizeOutgoingChat(const char *in, char *out, int outSize)
{
    int r;
    int w;
    unsigned char c;
    if (!in || !out || outSize <= 1) { return 0; }
    if (NetV61_IsDangerousLocalChatCommand(in)) {
        NetV60_SetStatus("Blocked unsafe local chat command. Chat is never executed as an OS command.");
        return 0;
    }
    r = 0;
    w = 0;
    while (in[r] && w < outSize - 1 && w < NETV61_MAX_CHAT_CHARS) {
        c = (unsigned char)in[r++];
        if (c == '\r' || c == '\n' || c == '\t') { c = ' '; }
        if (NetV61_IsSafeAsciiForChat(c)) { out[w++] = (char)c; }
    }
    out[w] = 0;
    NetV60_Trim(out);
    return out[0] ? 1 : 0;
}

static int NetV61_CheckChatRate(void)
{
    double now;
    now = g_netV60TimeNow;
    if (now <= 0.0) { now = NetV60_TimeSeconds(); }
    if (now - g_netV61LastChatTime < NETV61_CHAT_MIN_INTERVAL) {
        NetV60_SetStatus("Chat rate limited to protect the client/server connection.");
        return 0;
    }
    if (now - g_netV61ChatWindowStart > NETV61_CHAT_BURST_WINDOW) {
        g_netV61ChatWindowStart = now;
        g_netV61ChatBurstCount = 0;
    }
    g_netV61ChatBurstCount++;
    if (g_netV61ChatBurstCount > NETV61_CHAT_BURST_LIMIT) {
        NetV60_SetStatus("Chat burst blocked by multiplayer security guard.");
        return 0;
    }
    g_netV61LastChatTime = now;
    return 1;
}

static int NetV61_IsReasonableCoordLong(long v)
{
    if (v < -NETV61_MAX_ABS_COORD || v > NETV61_MAX_ABS_COORD) { return 0; }
    return 1;
}

static int NetV61_IsReasonableCoordDouble(double v)
{
    if (v < -30000000.0 || v > 30000000.0) { return 0; }
    return 1;
}

static int NetV61_ValidateServerCorrection(double x, double y, double z)
{
    double lx;
    double ly;
    double lz;
    if (!NetV61_IsReasonableCoordDouble(x) || !NetV61_IsReasonableCoordDouble(y) || !NetV61_IsReasonableCoordDouble(z)) { return 0; }
    if (y < -128.0 || y > 512.0) { return 0; }
    if (g_state == STATE_GAME) {
        lx = x - ((double)worldOriginBlockX + playerX);
        ly = y - playerY;
        lz = z - ((double)worldOriginBlockZ + playerZ);
        if (fabs(lx) > NETV61_MAX_SERVER_CORRECTION || fabs(ly) > NETV61_MAX_SERVER_CORRECTION || fabs(lz) > NETV61_MAX_SERVER_CORRECTION) { return 0; }
    }
    return 1;
}

static void NetV61_ConfigureSocket(SOCKET s)
{
    BOOL b;
    int ms;
    int tos;
    b = TRUE;
    setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (const char *)&b, sizeof(b));
    b = TRUE;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char *)&b, sizeof(b));
    ms = NETV61_SOCKET_RECV_TIMEOUT_MS;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&ms, sizeof(ms));
    ms = NETV61_SOCKET_SEND_TIMEOUT_MS;
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char *)&ms, sizeof(ms));
    tos = 0x18; /* Java Beta NetworkManager requested traffic class 24. Best-effort only. */
    (void)setsockopt(s, IPPROTO_IP, IP_TOS, (const char *)&tos, sizeof(tos));
}

static void NetV61_ResetTickBudget(void)
{
    g_netV61BytesThisTick = 0L;
    g_netV61PacketsThisTick = 0;
    g_netV76ChunkPacketsThisTick = 0;
}

static void NetV60_ResetSocketOnly(void)
{
    if (g_netV60Socket != INVALID_SOCKET) {
        shutdown(g_netV60Socket, SD_BOTH);
        closesocket(g_netV60Socket);
        g_netV60Socket = INVALID_SOCKET;
    }
    g_netV60ReadLen = 0;
}

const char *NetworkV60_GetStatus(void)
{
    return g_netV60Status;
}

int NetworkV60_IsConnecting(void)
{
    return g_netV60State == 1;
}

int NetworkV60_IsConnected(void)
{
    return g_netV60State == 2;
}

int NetworkV60_HasFailed(void)
{
    return g_netV60State == 3;
}

int NetworkV60_IsActive(void)
{
    return g_netV60State == 1 || g_netV60State == 2 || g_networkMultiplayerActive;
}

static void NetV60_Fail(const char *reason)
{
    NetV60_ResetSocketOnly();
    g_netV61SecurityDisconnects++;
    g_netV60State = 3;
    g_networkMultiplayerActive = 0;
    g_netV77JoinHoldActive = 0;
    NetV60_SetStatus(reason ? reason : "Connection failed.");
    if (g_state == STATE_CONNECTING || g_state == STATE_DOWNLOAD_TERRAIN || g_state == STATE_GAME) {
        GuiV9_EnterConnectFailed(g_netV60Status);
    }
}

void NetworkV60_Disconnect(const char *reason)
{
    NetV60_ResetSocketOnly();
    g_netV60State = 0;
    g_networkMultiplayerActive = 0;
    g_netV60SawLogin = 0;
    g_netV77JoinHoldActive = 0;
    NetV60_SetStatus(reason ? reason : "Disconnected.");
}

static int NetV60_WinsockInit(void)
{
    WSADATA data;
    int rc;
    if (g_netV60WinsockReady) { return 1; }
    memset(&data, 0, sizeof(data));
    rc = WSAStartup(MAKEWORD(2, 2), &data);
    if (rc != 0) {
        rc = WSAStartup(MAKEWORD(2, 0), &data);
    }
    if (rc != 0) {
        NetV60_Fail("WinSock2 startup failed; multiplayer requires ws2_32.dll.");
        return 0;
    }
    if (LOBYTE(data.wVersion) < 2) {
        WSACleanup();
        NetV60_Fail("WinSock2 unavailable; refusing legacy Winsock1 network path.");
        return 0;
    }
    g_netV60WinsockReady = 1;
    return 1;
}

static void NetV60_Trim(char *s)
{
    int len;
    int start;
    int i;
    if (!s) { return; }
    start = 0;
    while (s[start] == ' ' || s[start] == '\t' || s[start] == '\r' || s[start] == '\n') { start++; }
    if (start > 0) {
        i = 0;
        while (s[start]) { s[i++] = s[start++]; }
        s[i] = 0;
    }
    len = (int)strlen(s);
    while (len > 0 && (s[len - 1] == ' ' || s[len - 1] == '\t' || s[len - 1] == '\r' || s[len - 1] == '\n')) {
        s[len - 1] = 0;
        len--;
    }
}

static int NetV60_ParseAddress(const char *input, char *host, int hostSize, int *port)
{
    char tmp[160];
    char *colon;
    char *endBracket;
    char *keySep;
    int i;
    int parsedPort;
    unsigned char c;
    unsigned char kc;
    if (!input || !host || hostSize <= 1 || !port) { return 0; }
    strncpy(tmp, input, sizeof(tmp) - 1);
    tmp[sizeof(tmp) - 1] = 0;
    NetV60_Trim(tmp);
    g_netV62ClassicKey[0] = 0;
    keySep = strchr(tmp, '#');
    if (keySep) {
        *keySep = 0;
        keySep++;
        strncpy(g_netV62ClassicKey, keySep, sizeof(g_netV62ClassicKey) - 1);
        g_netV62ClassicKey[sizeof(g_netV62ClassicKey) - 1] = 0;
        NetV60_Trim(g_netV62ClassicKey);
        for (i = 0; g_netV62ClassicKey[i]; i++) {
            kc = (unsigned char)g_netV62ClassicKey[i];
            if (kc < 33 || kc > 126) { g_netV62ClassicKey[i] = 0; break; }
        }
    }
    NetV60_Trim(tmp);
    if (!tmp[0]) { return 0; }
    *port = (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) ? NETV62_CLASSIC_DEFAULT_PORT : NETV60_DEFAULT_PORT;
    if (tmp[0] == '[') {
        endBracket = strchr(tmp, ']');
        if (endBracket && endBracket > tmp + 1) {
            *endBracket = 0;
            strncpy(host, tmp + 1, hostSize - 1);
            host[hostSize - 1] = 0;
            if (endBracket[1] == ':' && endBracket[2]) {
                parsedPort = atoi(endBracket + 2);
                if (parsedPort > 0 && parsedPort <= 65535) { *port = parsedPort; }
            }
        } else {
            return 0;
        }
    } else {
        colon = strrchr(tmp, ':');
        if (colon && strchr(tmp, ':') == colon) {
            *colon = 0;
            parsedPort = atoi(colon + 1);
            if (parsedPort > 0 && parsedPort <= 65535) { *port = parsedPort; }
        }
        strncpy(host, tmp, hostSize - 1);
        host[hostSize - 1] = 0;
    }
    NetV60_Trim(host);
    if (!host[0] || (int)strlen(host) > NETV61_MAX_HOST_CHARS) { return 0; }
    for (i = 0; host[i]; i++) {
        c = (unsigned char)host[i];
        if (c < 33 || c > 126) { return 0; }
        if (!(c == '-' || c == '.' || c == '_' || c == ':' ||
              (c >= '0' && c <= '9') ||
              (c >= 'A' && c <= 'Z') ||
              (c >= 'a' && c <= 'z'))) { return 0; }
    }
    return 1;
}

static int NetV60_ReadU8(const unsigned char *buf, int len, int *off, int *out)
{
    if (*off + 1 > len) { return 0; }
    *out = (int)buf[*off];
    *off += 1;
    return 1;
}

static int NetV60_ReadI16(const unsigned char *buf, int len, int *off, int *out)
{
    if (*off + 2 > len) { return 0; }
    *out = ((int)buf[*off] << 8) | (int)buf[*off + 1];
    if (*out & 0x8000) { *out -= 0x10000; }
    *off += 2;
    return 1;
}

static int NetV60_ReadU16(const unsigned char *buf, int len, int *off, int *out)
{
    if (*off + 2 > len) { return 0; }
    *out = ((int)buf[*off] << 8) | (int)buf[*off + 1];
    *off += 2;
    return 1;
}

static int NetV60_ReadI32(const unsigned char *buf, int len, int *off, long *out)
{
    unsigned long v;
    if (*off + 4 > len) { return 0; }
    v = ((unsigned long)buf[*off] << 24) |
        ((unsigned long)buf[*off + 1] << 16) |
        ((unsigned long)buf[*off + 2] << 8) |
        ((unsigned long)buf[*off + 3]);
    if (v & 0x80000000UL) { *out = -((long)((~v & 0xFFFFFFFFUL) + 1)); }
    else { *out = (long)v; }
    *off += 4;
    return 1;
}

static int NetV60_ReadU64(const unsigned char *buf, int len, int *off, unsigned long *hi, unsigned long *lo)
{
    if (*off + 8 > len) { return 0; }
    *hi = ((unsigned long)buf[*off] << 24) |
          ((unsigned long)buf[*off + 1] << 16) |
          ((unsigned long)buf[*off + 2] << 8) |
          ((unsigned long)buf[*off + 3]);
    *lo = ((unsigned long)buf[*off + 4] << 24) |
          ((unsigned long)buf[*off + 5] << 16) |
          ((unsigned long)buf[*off + 6] << 8) |
          ((unsigned long)buf[*off + 7]);
    *off += 8;
    return 1;
}

static int NetV60_ReadDouble(const unsigned char *buf, int len, int *off, double *out)
{
    union { unsigned char b[8]; double d; } u;
    int i;
    if (*off + 8 > len) { return 0; }
    for (i = 0; i < 8; i++) { u.b[7 - i] = buf[*off + i]; }
    *out = u.d;
    *off += 8;
    return 1;
}

static int NetV60_ReadFloat(const unsigned char *buf, int len, int *off, float *out)
{
    union { unsigned char b[4]; float f; } u;
    int i;
    if (*off + 4 > len) { return 0; }
    for (i = 0; i < 4; i++) { u.b[3 - i] = buf[*off + i]; }
    *out = u.f;
    *off += 4;
    return 1;
}

static int NetV60_ReadString(const unsigned char *buf, int len, int *off, int maxChars, char *out, int outSize)
{
    int chars;
    int i;
    int w;
    int codeHi;
    int codeLo;
    int code;
    char c;
    if (!NetV60_ReadI16(buf, len, off, &chars)) { return 0; }
    if (chars < 0 || chars > maxChars || chars > NETV60_MAX_STRING_CHARS) { return -1; }
    if (*off + chars * 2 > len) { *off -= 2; return 0; }
    w = 0;
    for (i = 0; i < chars; i++) {
        codeHi = (int)buf[*off + i * 2];
        codeLo = (int)buf[*off + i * 2 + 1];
        code = (codeHi << 8) | codeLo;
        if (code == 0x00A7) {
            /* Java Minecraft color/style marker; skip marker and style char. */
            if (i + 1 < chars) { i++; }
            continue;
        }
        if (codeHi == 0 && codeLo >= 32 && codeLo <= 126) {
            c = (char)codeLo;
            if (c == '&' && i + 1 < chars) {
                int nextHi = (int)buf[*off + (i + 1) * 2];
                int nextLo = (int)buf[*off + (i + 1) * 2 + 1];
                if (nextHi == 0 && NetV65_IsMinecraftColorCode((unsigned char)nextLo)) { i++; continue; }
            }
            if (w < outSize - 1) { out[w++] = c; }
        } else if (codeHi == 0 && (codeLo == '\n' || codeLo == '\r' || codeLo == '\t')) {
            if (w < outSize - 1) { out[w++] = ' '; }
        } else {
            /* Ignore unrenderable Unicode instead of drawing question-mark garbage. */
        }
    }
    if (outSize > 0) { out[w < outSize ? w : outSize - 1] = 0; }
    *off += chars * 2;
    return 1;
}

static int NetV60_SkipString(const unsigned char *buf, int len, int *off, int maxChars)
{
    char tmp[4];
    return NetV60_ReadString(buf, len, off, maxChars, tmp, sizeof(tmp));
}

static int NetV60_SkipUTF8(const unsigned char *buf, int len, int *off, int maxBytes)
{
    int bytes;
    if (!NetV60_ReadU16(buf, len, off, &bytes)) { return 0; }
    if (bytes < 0 || bytes > maxBytes) { return -1; }
    if (*off + bytes > len) { *off -= 2; return 0; }
    *off += bytes;
    return 1;
}

static int NetV60_SkipItemStack(const unsigned char *buf, int len, int *off)
{
    int id;
    if (!NetV60_ReadI16(buf, len, off, &id)) { return 0; }
    if (id >= 0) {
        if (*off + 3 > len) { *off -= 2; return 0; }
        *off += 3;
    }
    return 1;
}

static int NetV80_ToSignedByte(int v)
{
    v &= 255;
    if (v >= 128) { v -= 256; }
    return v;
}

static void NetV80_ClearItemStack(InventorySlot *slot)
{
    if (!slot) { return; }
    slot->item = ITEM_NONE;
    slot->count = 0;
    slot->damage = 0;
}

static int NetV80_ReadItemStack(const unsigned char *buf, int len, int *off, InventorySlot *out)
{
    int id;
    int count;
    int damage;
    if (!out) { return NetV60_SkipItemStack(buf, len, off); }
    NetV80_ClearItemStack(out);
    if (!NetV60_ReadI16(buf, len, off, &id)) { return 0; }
    if (id < 0) { return 1; }
    if (!NetV60_ReadU8(buf, len, off, &count)) { *off -= 2; return 0; }
    if (!NetV60_ReadI16(buf, len, off, &damage)) { return 0; }
    if (count < 0) { count = 0; }
    if (count > MAX_STACK) { count = MAX_STACK; }
    out->item = id;
    out->count = count;
    out->damage = damage;
    if (out->count <= 0) { NetV80_ClearItemStack(out); }
    return 1;
}

static void NetV80_WriteItemStack(unsigned char *buf, int *off, const InventorySlot *stack)
{
    if (!stack || stack->item == ITEM_NONE || stack->count <= 0) {
        NetV60_WriteU16(buf, off, 0xffff);
        return;
    }
    NetV60_WriteU16(buf, off, stack->item & 0x7fff);
    NetV60_WriteU8(buf, off, stack->count & 255);
    NetV60_WriteU16(buf, off, stack->damage & 0xffff);
}

static int NetV80_ReadUTF8String(const unsigned char *buf, int len, int *off, int maxBytes, char *out, int outSize)
{
    int bytes;
    int i;
    int w;
    unsigned char c;
    if (out && outSize > 0) { out[0] = 0; }
    if (!NetV60_ReadU16(buf, len, off, &bytes)) { return 0; }
    if (bytes < 0 || bytes > maxBytes) { return -1; }
    if (*off + bytes > len) { *off -= 2; return 0; }
    w = 0;
    for (i = 0; i < bytes; i++) {
        c = buf[*off + i];
        if (c >= 32 && c <= 126 && out && w < outSize - 1) { out[w++] = (char)c; }
    }
    if (out && outSize > 0) { out[w] = 0; NetV61_SanitizeDisplayText(out); }
    *off += bytes;
    return 1;
}

static int NetV60_SkipMetadata(const unsigned char *buf, int len, int *off)
{
    int header;
    int type;
    int rc;
    long ignore32;
    float ignoreF;
    while (1) {
        if (!NetV60_ReadU8(buf, len, off, &header)) { return 0; }
        if (header == 127) { return 1; }
        type = (header >> 5) & 7;
        if (type == 0) {
            if (*off + 1 > len) { return 0; }
            *off += 1;
        } else if (type == 1) {
            if (*off + 2 > len) { return 0; }
            *off += 2;
        } else if (type == 2) {
            if (!NetV60_ReadI32(buf, len, off, &ignore32)) { return 0; }
        } else if (type == 3) {
            if (!NetV60_ReadFloat(buf, len, off, &ignoreF)) { return 0; }
        } else if (type == 4) {
            rc = NetV60_SkipString(buf, len, off, 64);
            if (rc <= 0) { return rc; }
        } else if (type == 5) {
            rc = NetV60_SkipItemStack(buf, len, off);
            if (rc <= 0) { return rc; }
        } else if (type == 6) {
            if (*off + 12 > len) { return 0; }
            *off += 12;
        } else {
            return -1;
        }
    }
}

static void NetV60_WriteU8(unsigned char *buf, int *off, int v)
{
    buf[*off] = (unsigned char)(v & 255);
    *off += 1;
}

static void NetV60_WriteU16(unsigned char *buf, int *off, int v)
{
    buf[*off] = (unsigned char)((v >> 8) & 255);
    buf[*off + 1] = (unsigned char)(v & 255);
    *off += 2;
}

static void NetV60_WriteU32(unsigned char *buf, int *off, long v)
{
    unsigned long u = (unsigned long)v;
    buf[*off] = (unsigned char)((u >> 24) & 255);
    buf[*off + 1] = (unsigned char)((u >> 16) & 255);
    buf[*off + 2] = (unsigned char)((u >> 8) & 255);
    buf[*off + 3] = (unsigned char)(u & 255);
    *off += 4;
}

static void NetV60_WriteU64(unsigned char *buf, int *off, unsigned long hi, unsigned long lo)
{
    NetV60_WriteU32(buf, off, (long)hi);
    NetV60_WriteU32(buf, off, (long)lo);
}

static void NetV60_WriteDouble(unsigned char *buf, int *off, double d)
{
    union { unsigned char b[8]; double d; } u;
    int i;
    u.d = d;
    for (i = 0; i < 8; i++) { buf[*off + i] = u.b[7 - i]; }
    *off += 8;
}

static void NetV60_WriteFloat(unsigned char *buf, int *off, float f)
{
    union { unsigned char b[4]; float f; } u;
    int i;
    u.f = f;
    for (i = 0; i < 4; i++) { buf[*off + i] = u.b[3 - i]; }
    *off += 4;
}

static int NetV60_WriteString(unsigned char *buf, int cap, int *off, const char *text, int maxChars)
{
    int chars;
    int i;
    unsigned char c;
    if (!text) { text = ""; }
    chars = (int)strlen(text);
    if (chars > maxChars) { chars = maxChars; }
    if (*off + 2 + chars * 2 > cap) { return 0; }
    NetV60_WriteU16(buf, off, chars);
    for (i = 0; i < chars; i++) {
        c = (unsigned char)text[i];
        if (c < 32 || c > 126) { c = '?'; }
        buf[*off] = 0;
        buf[*off + 1] = c;
        *off += 2;
    }
    return 1;
}

static int NetV60_SendRaw(const unsigned char *buf, int len)
{
    int sentTotal;
    int n;
    int err;
    int tries;
    if (!buf || len <= 0 || len > NETV60_SEND_BUFFER_SIZE) {
        NetV60_Fail("Blocked invalid outbound packet size.");
        return 0;
    }
    if (g_netV60Socket == INVALID_SOCKET || g_netV60State != 2) { return 0; }
    g_netV61LastSendTime = NetV60_TimeSeconds();
    sentTotal = 0;
    tries = 0;
    while (sentTotal < len) {
        n = send(g_netV60Socket, (const char *)buf + sentTotal, len - sentTotal, 0);
        if (n > 0) { sentTotal += n; tries = 0; continue; }
        err = WSAGetLastError();
        if ((err == WSAEWOULDBLOCK || err == WSAEINPROGRESS) && tries < 5) {
            Sleep(1);
            tries++;
            continue;
        }
        NetV60_Fail("Network send failed or timed out.");
        return 0;
    }
    return 1;
}

static int NetV60_SendHandshake(const char *name)
{
    unsigned char buf[NETV60_SEND_BUFFER_SIZE];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 2);
    if (!NetV60_WriteString(buf, sizeof(buf), &off, name, 16)) { return 0; }
    return NetV60_SendRaw(buf, off);
}

static int NetV60_SendLogin(const char *name)
{
    unsigned char buf[NETV60_SEND_BUFFER_SIZE];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 1);
    NetV60_WriteU32(buf, &off, NETV60_PROTOCOL_VERSION);
    if (!NetV60_WriteString(buf, sizeof(buf), &off, name, 16)) { return 0; }
    NetV60_WriteU64(buf, &off, 0UL, 0UL);
    NetV60_WriteU8(buf, &off, 0);
    return NetV60_SendRaw(buf, off);
}

static void NetV60_SendPacket10(void)
{
    unsigned char buf[2];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 10);
    NetV60_WriteU8(buf, &off, onGround ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

static void NetV60_SendPacket11(double x, double y, double stance, double z)
{
    unsigned char buf[64];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 11);
    NetV60_WriteDouble(buf, &off, x);
    NetV60_WriteDouble(buf, &off, y);
    NetV60_WriteDouble(buf, &off, stance);
    NetV60_WriteDouble(buf, &off, z);
    NetV60_WriteU8(buf, &off, onGround ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

static void NetV60_SendPacket12(float yyaw, float ppitch)
{
    unsigned char buf[16];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 12);
    NetV60_WriteFloat(buf, &off, yyaw);
    NetV60_WriteFloat(buf, &off, ppitch);
    NetV60_WriteU8(buf, &off, onGround ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

static void NetV60_SendPacket13(double x, double y, double stance, double z, float yyaw, float ppitch)
{
    unsigned char buf[80];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 13);
    NetV60_WriteDouble(buf, &off, x);
    NetV60_WriteDouble(buf, &off, y);
    NetV60_WriteDouble(buf, &off, stance);
    NetV60_WriteDouble(buf, &off, z);
    NetV60_WriteFloat(buf, &off, yyaw);
    NetV60_WriteFloat(buf, &off, ppitch);
    NetV60_WriteU8(buf, &off, onGround ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

void NetworkV60_SendChat(const char *message)
{
    unsigned char buf[NETV60_SEND_BUFFER_SIZE];
    char clean[NETV61_MAX_CHAT_CHARS + 1];
    int off;
    if (!NetworkV60_IsConnected() || !message || !message[0]) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { NetV62Classic_SendMessage(message); return; }
    if (!NetV61_CheckChatRate()) { return; }
    if (!NetV61_SanitizeOutgoingChat(message, clean, sizeof(clean))) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 3);
    if (!NetV60_WriteString(buf, sizeof(buf), &off, clean, NETV61_MAX_CHAT_CHARS)) { return; }
    NetV60_SendRaw(buf, off);
}

void NetworkV60_SendAnimation(int animationId)
{
    unsigned char buf[8];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 18);
    NetV60_WriteU32(buf, &off, (long)g_netV60EntityId);
    NetV60_WriteU8(buf, &off, animationId);
    NetV60_SendRaw(buf, off);
}

void NetworkV60_SendHeldItemChange(int itemId)
{
    unsigned char buf[4];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 16);
    NetV60_WriteU16(buf, &off, itemId & 0x7fff);
    NetV60_SendRaw(buf, off);
}

void NetworkV60_SendBlockDig(int status, int x, int y, int z, int face)
{
    unsigned char buf[16];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { NetV62Classic_SendSetBlock(x, y, z, 0, 0); return; }
    if (y < 0 || y > 255 || face < 0 || face > 5 || status < 0 || status > 5) { return; }
    if (!NetV61_IsReasonableCoordLong((long)x) || !NetV61_IsReasonableCoordLong((long)z)) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 14);
    NetV60_WriteU8(buf, &off, status & 255);
    NetV60_WriteU32(buf, &off, (long)x);
    NetV60_WriteU8(buf, &off, y & 255);
    NetV60_WriteU32(buf, &off, (long)z);
    NetV60_WriteU8(buf, &off, face & 255);
    NetV60_SendRaw(buf, off);
}

void NetworkV60_SendPlace(int x, int y, int z, int face, int item)
{
    unsigned char buf[32];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { NetV62Classic_SendSetBlock(x, y, z, 1, item); return; }
    if (y < 0 || y > 255 || face < 0 || face > 5) { return; }
    if (!NetV61_IsReasonableCoordLong((long)x) || !NetV61_IsReasonableCoordLong((long)z)) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 15);
    NetV60_WriteU32(buf, &off, (long)x);
    NetV60_WriteU8(buf, &off, y & 255);
    NetV60_WriteU32(buf, &off, (long)z);
    NetV60_WriteU8(buf, &off, face & 255);
    if (item == ITEM_NONE) {
        NetV60_WriteU16(buf, &off, 0xffff);
    } else {
        NetV60_WriteU16(buf, &off, item & 0x7fff);
        NetV60_WriteU8(buf, &off, 1);
        NetV60_WriteU16(buf, &off, 0);
    }
    NetV60_SendRaw(buf, off);
}

void NetworkV80_SendUseEntity(int targetEntityId, int leftClick)
{
    unsigned char buf[16];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    if (targetEntityId <= 0 || g_netV60EntityId <= 0) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 7);
    NetV60_WriteU32(buf, &off, (long)g_netV60EntityId);
    NetV60_WriteU32(buf, &off, (long)targetEntityId);
    NetV60_WriteU8(buf, &off, leftClick ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

void NetworkV80_SendEntityAction(int actionState)
{
    unsigned char buf[8];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    if (g_netV60EntityId <= 0) { return; }
    if (actionState < 0 || actionState > 5) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 19);
    NetV60_WriteU32(buf, &off, (long)g_netV60EntityId);
    NetV60_WriteU8(buf, &off, actionState & 255);
    NetV60_SendRaw(buf, off);
}

static void NetV80_SendTransaction(int windowId, int actionNumber, int accepted)
{
    unsigned char buf[8];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 106);
    NetV60_WriteU8(buf, &off, windowId & 255);
    NetV60_WriteU16(buf, &off, actionNumber & 0xffff);
    NetV60_WriteU8(buf, &off, accepted ? 1 : 0);
    NetV60_SendRaw(buf, off);
}

void NetworkV80_SendWindowClick(int windowId, int slot, int mouseButton, int actionNumber, int shiftClick)
{
    unsigned char buf[32];
    int off;
    if (!NetworkV60_IsConnected()) { return; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return; }
    if (slot < -999 || slot > 127) { return; }
    off = 0;
    NetV60_WriteU8(buf, &off, 102);
    NetV60_WriteU8(buf, &off, windowId & 255);
    NetV60_WriteU16(buf, &off, slot & 0xffff);
    NetV60_WriteU8(buf, &off, mouseButton & 255);
    NetV60_WriteU16(buf, &off, actionNumber & 0xffff);
    NetV60_WriteU8(buf, &off, shiftClick ? 1 : 0);
    NetV80_WriteItemStack(buf, &off, &g_netV80CursorStack);
    g_netV80LastTransactionAction = (short)actionNumber;
    NetV60_SendRaw(buf, off);
}

static void NetV62Classic_WriteFixedString(unsigned char *buf, int *off, const char *text)
{
    int i;
    unsigned char c;
    for (i = 0; i < NETV62_CLASSIC_STRING_CHARS; i++) {
        c = ' ';
        if (text && text[i]) {
            c = (unsigned char)text[i];
            if (c < 32 || c > 126) { c = '?'; }
        }
        buf[*off] = c;
        *off += 1;
    }
}

static void NetV62Classic_ReadFixedString(const unsigned char *buf, int *off, char *out, int outSize)
{
    int i;
    int w;
    unsigned char c;
    w = 0;
    if (!out || outSize <= 0) { *off += NETV62_CLASSIC_STRING_CHARS; return; }
    for (i = 0; i < NETV62_CLASSIC_STRING_CHARS; i++) {
        c = buf[*off + i];
        if (c == '&' && i + 1 < NETV62_CLASSIC_STRING_CHARS && NetV65_IsMinecraftColorCode(buf[*off + i + 1])) { i++; continue; }
        if (c >= 32 && c <= 126 && w < outSize - 1) { out[w++] = (char)c; }
    }
    out[w] = 0;
    NetV61_SanitizeDisplayText(out);
    w = (int)strlen(out);
    while (w > 0 && out[w - 1] == ' ') { out[--w] = 0; }
    *off += NETV62_CLASSIC_STRING_CHARS;
}

static int NetV62Classic_SendIdentification(void)
{
    unsigned char buf[140];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 0);
    NetV60_WriteU8(buf, &off, 7);
    NetV62Classic_WriteFixedString(buf, &off, NetworkV62_GetUsername());
    NetV62Classic_WriteFixedString(buf, &off, g_netV62ClassicKey);
    NetV60_WriteU8(buf, &off, 0);
    return NetV60_SendRaw(buf, off);
}

static int NetV62Classic_SendExtInfo(void)
{
    unsigned char buf[80];
    int off;
    off = 0;
    NetV60_WriteU8(buf, &off, 16);
    NetV62Classic_WriteFixedString(buf, &off, "CloneMC V80");
    NetV60_WriteU16(buf, &off, 0); /* no CPE extensions claimed; parser still accepts server CPE records. */
    return NetV60_SendRaw(buf, off);
}

static int NetV62Classic_SendMessage(const char *message)
{
    unsigned char buf[80];
    char clean[NETV61_MAX_CHAT_CHARS + 1];
    int off;
    if (!NetV61_CheckChatRate()) { return 0; }
    if (!NetV61_SanitizeOutgoingChat(message, clean, sizeof(clean))) { return 0; }
    off = 0;
    NetV60_WriteU8(buf, &off, 13);
    NetV60_WriteU8(buf, &off, 0xff);
    NetV62Classic_WriteFixedString(buf, &off, clean);
    return NetV60_SendRaw(buf, off);
}

static int NetV62Classic_SendSetBlock(int gx, int gy, int gz, int create, int block)
{
    unsigned char buf[16];
    int off;
    int lx;
    int lz;
    if (!NetworkV60_IsConnected()) { return 0; }
    lx = gx - worldOriginBlockX;
    lz = gz - worldOriginBlockZ;
    if (lx < 0 || lx >= g_netV62ClassicLevelX || gy < 0 || gy >= g_netV62ClassicLevelY || lz < 0 || lz >= g_netV62ClassicLevelZ) { return 0; }
    off = 0;
    NetV60_WriteU8(buf, &off, 5);
    NetV60_WriteU16(buf, &off, lx & 0xffff);
    NetV60_WriteU16(buf, &off, gy & 0xffff);
    NetV60_WriteU16(buf, &off, lz & 0xffff);
    NetV60_WriteU8(buf, &off, create ? 1 : 0);
    NetV60_WriteU8(buf, &off, create ? (block & 255) : 0);
    return NetV60_SendRaw(buf, off);
}

static void NetV62_SendInitialHandshake(void)
{
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) {
        NetV60_SetStatus("Connected. Sending Classic/ClassiCube identification with chosen username...");
        NetV62Classic_SendIdentification();
        NetV62Classic_SendExtInfo();
    } else {
        NetV60_SetStatus("Connected. Sending Beta 1.7.3 handshake with chosen username...");
        NetV60_SendHandshake(NetworkV62_GetUsername());
    }
}

static int NetV60_ServerBlockToLocal(int block)
{
    if (block == BLOCK_TALL_GRASS || block == BLOCK_DEAD_BUSH) { return BLOCK_AIR; }
    if (block < 0 || block > 255) { return BLOCK_AIR; }
    return block;
}

static void NetV60_ApplyBlockGlobal(int gx, int gy, int gz, int block, int meta)
{
    int lx;
    int lz;
    int localBlock;
    lx = gx - worldOriginBlockX;
    lz = gz - worldOriginBlockZ;
    if (lx < 0 || lx >= WORLD_X || gy < 0 || gy >= WORLD_Y || lz < 0 || lz >= WORLD_Z) { return; }
    localBlock = NetV60_ServerBlockToLocal(block);
    world[lx][gy][lz] = localBlock;
    g_blockMeta[lx][gy][lz] = (unsigned char)(meta & 15);
    if (g_netV69RemoteBatchApply) { return; }
    RebuildColumnTopAt(lx, lz);
    RecomputeLegacyLightingLocal(lx, gy, lz, 18);
    InvalidateTerrainChunkMeshAt(lx, lz);
}

static int NetV60_LoadZlib(void)
{
    const char *names[4];
    int i;
    if (g_netV60TriedZlib) { return g_netV60Uncompress != NULL; }
    g_netV60TriedZlib = 1;
    names[0] = "zlib1.dll";
    names[1] = "zlib.dll";
    names[2] = "DLLS\\zlib1.dll";
    names[3] = "DLLS\\zlib.dll";
    for (i = 0; i < 4; i++) {
        g_netV60ZlibModule = LoadLibraryA(names[i]);
        if (!g_netV60ZlibModule) { continue; }
        g_netV60Uncompress = (NetV60_ZlibUncompressProc)GetProcAddress(g_netV60ZlibModule, "uncompress");
        if (g_netV60Uncompress) {
            strncpy(g_netV65ZlibDllName, names[i], sizeof(g_netV65ZlibDllName) - 1);
            g_netV65ZlibDllName[sizeof(g_netV65ZlibDllName) - 1] = 0;
            return 1;
        }
        FreeLibrary(g_netV60ZlibModule);
        g_netV60ZlibModule = NULL;
    }
    return 0;
}

static int NetV60_ReadNibbleV68(const unsigned char *src, long base, long index, long totalBytes)
{
    long p;
    int v;
    p = base + (index >> 1);
    if (p < 0 || p >= totalBytes) { return 0; }
    v = (int)src[p];
    if (index & 1L) { return (v >> 4) & 15; }
    return v & 15;
}

static int NetV76_ClampInt(int v, int lo, int hi)
{
    if (v < lo) { return lo; }
    if (v > hi) { return hi; }
    return v;
}

static void NetV76_MarkLocalChunkDirtyDirect(int cx, int cz)
{
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return; }
    terrainChunkDirty[cx][cz] = 1;
    terrainChunkTransDirty[cx][cz] = 1;
    terrainChunkSkipPassSolidV47[cx][cz] = 0;
    terrainChunkSkipPassTransV47[cx][cz] = 0;
    terrainChunkHasSpecialV47[cx][cz] = 1;
    if (terrainChunkDirtyAgeV33[cx][cz] < 65535) { terrainChunkDirtyAgeV33[cx][cz]++; }
    terrainChunkMeshOriginX = worldOriginBlockX;
    terrainChunkMeshOriginZ = worldOriginBlockZ;
}

static void NetV76_MarkLocalBlockRangeDirty(int minX, int minZ, int maxX, int maxZ)
{
    int minCX;
    int maxCX;
    int minCZ;
    int maxCZ;
    int cx;
    int cz;
    if (maxX < 0 || maxZ < 0 || minX >= WORLD_X || minZ >= WORLD_Z) { return; }
    minX = NetV76_ClampInt(minX, 0, WORLD_X - 1);
    maxX = NetV76_ClampInt(maxX, 0, WORLD_X - 1);
    minZ = NetV76_ClampInt(minZ, 0, WORLD_Z - 1);
    maxZ = NetV76_ClampInt(maxZ, 0, WORLD_Z - 1);
    minCX = minX / CHUNK_SIZE;
    maxCX = maxX / CHUNK_SIZE;
    minCZ = minZ / CHUNK_SIZE;
    maxCZ = maxZ / CHUNK_SIZE;

    /* Java RenderGlobal.markBlocksForUpdate/markBlocksDirty behavior: include
       one neighboring chunk around the edited range so seam faces rebuild when
       a border block changes.  This is much cheaper than invalidating every
       local chunk after each server Packet51 during join. */
    for (cx = minCX - 1; cx <= maxCX + 1; cx++) {
        for (cz = minCZ - 1; cz <= maxCZ + 1; cz++) {
            NetV76_MarkLocalChunkDirtyDirect(cx, cz);
        }
    }
}

static void NetV76_RebuildColumnTopsLocalRange(int minX, int minZ, int maxX, int maxZ)
{
    int x;
    int z;
    if (maxX < 0 || maxZ < 0 || minX >= WORLD_X || minZ >= WORLD_Z) { return; }
    minX = NetV76_ClampInt(minX, 0, WORLD_X - 1);
    maxX = NetV76_ClampInt(maxX, 0, WORLD_X - 1);
    minZ = NetV76_ClampInt(minZ, 0, WORLD_Z - 1);
    maxZ = NetV76_ClampInt(maxZ, 0, WORLD_Z - 1);
    for (x = minX; x <= maxX; x++) {
        for (z = minZ; z <= maxZ; z++) {
            RebuildColumnTopAt(x, z);
        }
    }
}

static void NetV76_DeferRemotePostRange(int minX, int minZ, int maxX, int maxZ)
{
    if (maxX < 0 || maxZ < 0 || minX >= WORLD_X || minZ >= WORLD_Z) { return; }
    minX = NetV76_ClampInt(minX, 0, WORLD_X - 1);
    maxX = NetV76_ClampInt(maxX, 0, WORLD_X - 1);
    minZ = NetV76_ClampInt(minZ, 0, WORLD_Z - 1);
    maxZ = NetV76_ClampInt(maxZ, 0, WORLD_Z - 1);
    if (!g_netV76DeferredPostDirty) {
        g_netV76DeferredMinX = minX;
        g_netV76DeferredMaxX = maxX;
        g_netV76DeferredMinZ = minZ;
        g_netV76DeferredMaxZ = maxZ;
    } else {
        if (minX < g_netV76DeferredMinX) { g_netV76DeferredMinX = minX; }
        if (maxX > g_netV76DeferredMaxX) { g_netV76DeferredMaxX = maxX; }
        if (minZ < g_netV76DeferredMinZ) { g_netV76DeferredMinZ = minZ; }
        if (maxZ > g_netV76DeferredMaxZ) { g_netV76DeferredMaxZ = maxZ; }
    }
    g_netV76DeferredPostDirty = 1;
}

static void NetV76_FinishDeferredRemotePost(void)
{
    if (!g_netV76DeferredPostDirty) { return; }

    NetV76_RebuildColumnTopsLocalRange(g_netV76DeferredMinX, g_netV76DeferredMinZ,
                                       g_netV76DeferredMaxX, g_netV76DeferredMaxZ);
    NetV76_MarkLocalBlockRangeDirty(g_netV76DeferredMinX, g_netV76DeferredMinZ,
                                    g_netV76DeferredMaxX, g_netV76DeferredMaxZ);

    /* Use the server's blocklight/skylight arrays from Packet51 when present.
       That avoids full ComputeLegacyLighting() for every map chunk.  If a server
       sends an odd/partial chunk without light data, fall back to one legacy
       recompute after the tick's batch instead of after every packet. */
    if (!g_netV76ServerLightAccepted && g_netV76ServerLightMissing) {
        ComputeLegacyLighting();
    }

    g_renderV47InitialBuildBoostFrames = 6;
    if (g_networkMultiplayerActive && g_chunkMeshBuildBudget > 2) { g_chunkMeshBuildBudget = 2; }
    g_netV76DeferredPostDirty = 0;
    g_netV76DeferredMinX = WORLD_X;
    g_netV76DeferredMinZ = WORLD_Z;
    g_netV76DeferredMaxX = -1;
    g_netV76DeferredMaxZ = -1;
    g_netV76ServerLightAccepted = 0;
    g_netV76ServerLightMissing = 0;
}

static void NetV76_ScheduleRemoteChunkPost(int gx0, int gz0, int gx1, int gz1)
{
    int lx0;
    int lz0;
    int lx1;
    int lz1;
    lx0 = gx0 - worldOriginBlockX;
    lz0 = gz0 - worldOriginBlockZ;
    lx1 = gx1 - worldOriginBlockX;
    lz1 = gz1 - worldOriginBlockZ;
    NetV76_DeferRemotePostRange(lx0, lz0, lx1, lz1);
}

static void NetV76_ClearRemoteChunkIfLocal(int chunkX, int chunkZ)
{
    int gx0;
    int gz0;
    int lx0;
    int lz0;
    int x;
    int y;
    int z;
    gx0 = chunkX * CHUNK_SIZE;
    gz0 = chunkZ * CHUNK_SIZE;
    lx0 = gx0 - worldOriginBlockX;
    lz0 = gz0 - worldOriginBlockZ;
    if (lx0 + CHUNK_SIZE <= 0 || lz0 + CHUNK_SIZE <= 0 || lx0 >= WORLD_X || lz0 >= WORLD_Z) { return; }
    for (x = NetV76_ClampInt(lx0, 0, WORLD_X - 1); x <= NetV76_ClampInt(lx0 + CHUNK_SIZE - 1, 0, WORLD_X - 1); x++) {
        for (z = NetV76_ClampInt(lz0, 0, WORLD_Z - 1); z <= NetV76_ClampInt(lz0 + CHUNK_SIZE - 1, 0, WORLD_Z - 1); z++) {
            for (y = 0; y < WORLD_Y; y++) {
                world[x][y][z] = BLOCK_AIR;
                g_blockMeta[x][y][z] = 0;
                skyLight[x][y][z] = 15;
                blockLight[x][y][z] = 0;
            }
        }
    }
    NetV77_MarkRemoteChunkDataGlobalChunk(chunkX, chunkZ, 0);
    NetV76_DeferRemotePostRange(lx0, lz0, lx0 + CHUNK_SIZE - 1, lz0 + CHUNK_SIZE - 1);
}


static void NetV77_ResetRemoteChunkDataFlags(void)
{
    memset(g_netV77RemoteChunkData, 0, sizeof(g_netV77RemoteChunkData));
    memset(g_netV79RemoteChunkPrepared, 0, sizeof(g_netV79RemoteChunkPrepared));
    memset(g_netV79RemoteChunkCollisionReady, 0, sizeof(g_netV79RemoteChunkCollisionReady));
    g_netV77ChunksDataThisJoin = 0;
    g_netV79PreparedChunksThisJoin = 0;
    g_netV79CollisionChunksThisJoin = 0;
    g_netV79JoinReleasedForTerrain = 0;
}

static void NetV79_SetLocalChunkPrepared(int cx, int cz, int prepared)
{
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return; }
    if (prepared) {
        if (!g_netV79RemoteChunkPrepared[cx][cz]) { g_netV79PreparedChunksThisJoin++; }
        g_netV79RemoteChunkPrepared[cx][cz] = 1;
    } else {
        if (g_netV79RemoteChunkPrepared[cx][cz] && g_netV79PreparedChunksThisJoin > 0) { g_netV79PreparedChunksThisJoin--; }
        g_netV79RemoteChunkPrepared[cx][cz] = 0;
    }
}

static void NetV79_SetLocalChunkCollisionReady(int cx, int cz, int ready)
{
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return; }
    if (ready) {
        if (!g_netV79RemoteChunkCollisionReady[cx][cz]) { g_netV79CollisionChunksThisJoin++; }
        g_netV79RemoteChunkCollisionReady[cx][cz] = 1;
    } else {
        if (g_netV79RemoteChunkCollisionReady[cx][cz] && g_netV79CollisionChunksThisJoin > 0) { g_netV79CollisionChunksThisJoin--; }
        g_netV79RemoteChunkCollisionReady[cx][cz] = 0;
    }
}

static void NetV77_MarkRemoteChunkDataLocal(int cx, int cz, int hasData)
{
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return; }
    if (hasData) {
        if (!g_netV77RemoteChunkData[cx][cz]) { g_netV77ChunksDataThisJoin++; }
        g_netV77RemoteChunkData[cx][cz] = 1;
        NetV79_SetLocalChunkPrepared(cx, cz, 1);
        NetV79_SetLocalChunkCollisionReady(cx, cz, 1);
        g_netV79LastTerrainChunkTime = NetV60_TimeSeconds();
    } else {
        if (g_netV77RemoteChunkData[cx][cz] && g_netV77ChunksDataThisJoin > 0) { g_netV77ChunksDataThisJoin--; }
        g_netV77RemoteChunkData[cx][cz] = 0;
        /* Packet50 prepare(false)/unload clears prepared separately when possible;
           a prepare(true) must be allowed to set prepared while terrain stays false. */
        NetV79_SetLocalChunkCollisionReady(cx, cz, 0);
    }
}

static int NetV79_GlobalChunkToLocalChunk(int chunkX, int chunkZ, int *outCX, int *outCZ)
{
    int lx0;
    int lz0;
    int cx;
    int cz;
    lx0 = chunkX * CHUNK_SIZE - worldOriginBlockX;
    lz0 = chunkZ * CHUNK_SIZE - worldOriginBlockZ;
    if (lx0 + CHUNK_SIZE <= 0 || lz0 + CHUNK_SIZE <= 0 || lx0 >= WORLD_X || lz0 >= WORLD_Z) { return 0; }
    cx = lx0 / CHUNK_SIZE;
    cz = lz0 / CHUNK_SIZE;
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return 0; }
    if (outCX) { *outCX = cx; }
    if (outCZ) { *outCZ = cz; }
    return 1;
}

static void NetV77_MarkRemoteChunkDataGlobalChunk(int chunkX, int chunkZ, int hasData)
{
    int cx;
    int cz;
    if (!NetV79_GlobalChunkToLocalChunk(chunkX, chunkZ, &cx, &cz)) { return; }
    NetV77_MarkRemoteChunkDataLocal(cx, cz, hasData);
}

static void NetV77_MarkRemoteChunkDataLocalRange(int minX, int minZ, int maxX, int maxZ)
{
    int minCX;
    int maxCX;
    int minCZ;
    int maxCZ;
    int cx;
    int cz;
    if (maxX < 0 || maxZ < 0 || minX >= WORLD_X || minZ >= WORLD_Z) { return; }
    minX = NetV76_ClampInt(minX, 0, WORLD_X - 1);
    maxX = NetV76_ClampInt(maxX, 0, WORLD_X - 1);
    minZ = NetV76_ClampInt(minZ, 0, WORLD_Z - 1);
    maxZ = NetV76_ClampInt(maxZ, 0, WORLD_Z - 1);
    minCX = minX / CHUNK_SIZE;
    maxCX = maxX / CHUNK_SIZE;
    minCZ = minZ / CHUNK_SIZE;
    maxCZ = maxZ / CHUNK_SIZE;
    for (cx = minCX; cx <= maxCX; cx++) {
        for (cz = minCZ; cz <= maxCZ; cz++) {
            NetV77_MarkRemoteChunkDataLocal(cx, cz, 1);
        }
    }
}

static void NetV79_PrepareRemoteChunkGlobal(int chunkX, int chunkZ)
{
    int cx;
    int cz;
    int gx0;
    int gz0;
    int lx0;
    int lz0;
    int x;
    int y;
    int z;
    if (!NetV79_GlobalChunkToLocalChunk(chunkX, chunkZ, &cx, &cz)) { return; }
    gx0 = chunkX * CHUNK_SIZE;
    gz0 = chunkZ * CHUNK_SIZE;
    lx0 = gx0 - worldOriginBlockX;
    lz0 = gz0 - worldOriginBlockZ;
    for (x = NetV76_ClampInt(lx0, 0, WORLD_X - 1); x <= NetV76_ClampInt(lx0 + CHUNK_SIZE - 1, 0, WORLD_X - 1); x++) {
        for (z = NetV76_ClampInt(lz0, 0, WORLD_Z - 1); z <= NetV76_ClampInt(lz0 + CHUNK_SIZE - 1, 0, WORLD_Z - 1); z++) {
            for (y = 0; y < WORLD_Y; y++) {
                world[x][y][z] = BLOCK_AIR;
                g_blockMeta[x][y][z] = 0;
                skyLight[x][y][z] = 15;
                blockLight[x][y][z] = 0;
            }
        }
    }
    NetV79_SetLocalChunkPrepared(cx, cz, 1);
    NetV77_MarkRemoteChunkDataLocal(cx, cz, 0);
    NetV76_DeferRemotePostRange(lx0, lz0, lx0 + CHUNK_SIZE - 1, lz0 + CHUNK_SIZE - 1);
}

static int NetV79_LocalChunkTerrainReady(int cx, int cz)
{
    if (cx < 0 || cx >= WORLD_CHUNKS_X || cz < 0 || cz >= WORLD_CHUNKS_Z) { return 0; }
    return g_netV77RemoteChunkData[cx][cz] ? 1 : 0;
}

int NetworkV79_IsLocalBlockInLoadedServerChunk(int x, int y, int z)
{
    int cx;
    int cz;
    if (!g_networkMultiplayerActive || g_netV62ProtocolMode != NETV62_PROTOCOL_BETA173) { return 1; }
    if (x < 0 || x >= WORLD_X || z < 0 || z >= WORLD_Z || y < 0 || y >= WORLD_Y) { return 0; }
    cx = x / CHUNK_SIZE;
    cz = z / CHUNK_SIZE;
    return NetV79_LocalChunkTerrainReady(cx, cz);
}

int NetworkV79_ShouldTreatMissingTerrainAsSolid(int x, int y, int z, double testFeetY)
{
    int feetY;
    int cx;
    int cz;
    if (!g_networkMultiplayerActive || g_netV62ProtocolMode != NETV62_PROTOCOL_BETA173) { return 0; }
    if (x < 0 || x >= WORLD_X || z < 0 || z >= WORLD_Z || y < 0 || y >= WORLD_Y) { return 0; }
    cx = x / CHUNK_SIZE;
    cz = z / CHUNK_SIZE;
    if (NetV79_LocalChunkTerrainReady(cx, cz)) { return 0; }
    feetY = (int)floor(testFeetY);
    if (y <= feetY - 1) { return 1; }
    return 0;
}

static void NetV79_EnsureWindowForIncomingTerrain(int blockX, int blockZ)
{
    double targetGX;
    double targetGZ;
    if (g_netV77SawServerPosition) {
        targetGX = g_netV77LastServerGX;
        targetGZ = g_netV77LastServerGZ;
    } else if (g_netV77SawSpawnPacket) {
        targetGX = g_worldSpawnGlobalX;
        targetGZ = g_worldSpawnGlobalZ;
    } else {
        targetGX = (double)blockX + 8.0;
        targetGZ = (double)blockZ + 8.0;
    }
    NetV68_EnsureWindowForGlobal(targetGX, targetGZ);
}

static int NetV77_PlayerLocalChunkDataReady(void)
{
    int cx;
    int cz;
    /* V78: follow the uploaded Java client more closely.
       EntityClientPlayerMP.onUpdate gates movement with blockExists(floor(posX),64,floor(posZ)),
       which is a center-chunk test, not a full player-width/two-chunk test.
       The V77 bounding-width check could freeze the player forever at chunk edges. */
    if (playerX < 0.0 || playerZ < 0.0 || playerX >= (double)WORLD_X || playerZ >= (double)WORLD_Z) { return 0; }
    cx = NetV76_ClampInt((int)floor(playerX) / CHUNK_SIZE, 0, WORLD_CHUNKS_X - 1);
    cz = NetV76_ClampInt((int)floor(playerZ) / CHUNK_SIZE, 0, WORLD_CHUNKS_Z - 1);
    if (g_netV77RemoteChunkData[cx][cz]) {
        g_netV78JoinCenterReadyOnce = 1;
        return 1;
    }
    return 0;
}

static int NetV78_AnyRemoteChunkDataReady(void)
{
    return g_netV77ChunksDataThisJoin > 0 ? 1 : 0;
}

static int NetV78_FindSafeGroundYNearPlayer(double *outY)
{
    int px;
    int pz;
    int radius;
    int x;
    int z;
    int y;
    int block;
    int head1;
    int head2;
    int bestDist2;
    int dist2;
    double bestY;
    if (!outY) { return 0; }
    if (playerX < 0.0 || playerZ < 0.0 || playerX >= (double)WORLD_X || playerZ >= (double)WORLD_Z) { return 0; }
    px = (int)floor(playerX);
    pz = (int)floor(playerZ);
    bestDist2 = 999999;
    bestY = playerY;
    for (radius = 0; radius <= 2; radius++) {
        for (x = px - radius; x <= px + radius; x++) {
            for (z = pz - radius; z <= pz + radius; z++) {
                if (x < 0 || x >= WORLD_X || z < 0 || z >= WORLD_Z) { continue; }
                if (!g_netV77RemoteChunkData[x / CHUNK_SIZE][z / CHUNK_SIZE]) { continue; }
                for (y = WORLD_Y - 3; y >= 1; y--) {
                    block = GetBlock(x, y, z);
                    if (!IsSolidBlock(block) && block != BLOCK_WATER) { continue; }
                    head1 = GetBlock(x, y + 1, z);
                    head2 = GetBlock(x, y + 2, z);
                    if (IsSolidBlock(head1) || IsSolidBlock(head2)) { continue; }
                    dist2 = (x - px) * (x - px) + (z - pz) * (z - pz);
                    if (dist2 < bestDist2) {
                        bestDist2 = dist2;
                        bestY = (double)y + 1.02;
                    }
                    break;
                }
            }
        }
        if (bestDist2 < 999999) {
            *outY = bestY;
            return 1;
        }
    }
    return 0;
}

static int NetV77_BlockSupportsJoinRelease(int block)
{
    if (block == BLOCK_WATER) { return 1; }
    if (block == BLOCK_LAVA || block == BLOCK_STATIONARY_LAVA) { return 1; }
    return IsSolidBlock(block);
}

static int NetV77_PlayerHasLoadedGroundNearby(void)
{
    int px;
    int pz;
    int y;
    int x;
    int z;
    int minY;
    int maxDrop;
    int block;
    if (!NetV77_PlayerLocalChunkDataReady()) { return 0; }
    px = (int)floor(playerX);
    pz = (int)floor(playerZ);
    minY = (int)floor(playerY) - 1;
    if (minY >= WORLD_Y) { minY = WORLD_Y - 1; }
    if (minY < 0) { return 0; }
    maxDrop = minY - 14;
    if (maxDrop < 0) { maxDrop = 0; }
    for (y = minY; y >= maxDrop; y--) {
        for (x = px - 1; x <= px + 1; x++) {
            for (z = pz - 1; z <= pz + 1; z++) {
                if (x < 0 || x >= WORLD_X || z < 0 || z >= WORLD_Z) { continue; }
                block = GetBlock(x, y, z);
                if (NetV77_BlockSupportsJoinRelease(block)) { return 1; }
            }
        }
    }
    return 0;
}

static void NetV77_BeginJoinHold(void)
{
    g_netV77JoinHoldActive = 1;
    g_netV77SawServerPosition = 0;
    g_netV77JoinSafeAnnounced = 0;
    g_netV77ChunksDataThisJoin = 0;
    g_netV77JoinHoldStartTime = NetV60_TimeSeconds();
    g_netV78JoinReleasedByTimeout = 0;
    g_netV78JoinCenterReadyOnce = 0;
    g_netV79JoinReleasedForTerrain = 0;
    NetV77_ResetRemoteChunkDataFlags();
    velocityX = 0.0;
    velocityY = 0.0;
    velocityZ = 0.0;
    onGround = 1;
}

static void NetV77_CheckJoinHoldRelease(void)
{
    double elapsed;
    int centerReady;
    int groundReady;
    int anyChunkReady;
    double safeY;
    if (!g_netV77JoinHoldActive) { return; }
    elapsed = NetV60_TimeSeconds() - g_netV77JoinHoldStartTime;
    if (!g_netV77SawServerPosition) {
        NetV60_SetStatus("Waiting for authoritative server spawn position...");
        velocityX = 0.0;
        velocityY = 0.0;
        velocityZ = 0.0;
        onGround = 1;
        g_playerFallDistanceV22 = 0.0;
        return;
    }

    centerReady = NetV77_PlayerLocalChunkDataReady();
    anyChunkReady = NetV78_AnyRemoteChunkDataReady();
    groundReady = centerReady ? NetV77_PlayerHasLoadedGroundNearby() : 0;

    /* V79: Java NetClientHandler releases the download-terrain screen after the
       first authoritative position correction; ChunkProviderClient then uses a
       blank chunk fallback while Packet50/51 chunks keep streaming.  CloneMC
       now mirrors that feel: hold briefly, release once the center chunk is
       ready, or release after a short timeout with missing-terrain floor
       collision so the player can move/look without falling through unloaded
       server terrain. */
    if (centerReady || elapsed >= NETV79_CENTER_CHUNK_RELEASE_SECONDS || (anyChunkReady && elapsed >= 0.75) || elapsed >= NETV78_JOIN_HARD_RELEASE_SECONDS) {
        if (centerReady && groundReady && NetV78_FindSafeGroundYNearPlayer(&safeY)) {
            if (fabs(playerY - safeY) <= 10.0 || playerY > safeY) {
                playerY = safeY;
                onGround = 1;
            } else {
                onGround = 0;
            }
        } else {
            onGround = 1;
        }
        g_netV77JoinHoldActive = 0;
        g_netV79JoinReleasedForTerrain = 1;
        g_netV78JoinReleasedByTimeout = (!centerReady) ? 1 : 0;
        velocityX = 0.0;
        velocityY = 0.0;
        velocityZ = 0.0;
        g_playerFallDistanceV22 = 0.0;
        if (!g_netV77JoinSafeAnnounced) {
            if (centerReady) { GuiV9_AddChatLine("Server spawn chunk loaded; movement released."); }
            else { GuiV9_AddChatLine("Movement released with temporary missing-terrain collision; server chunks are still streaming."); }
            g_netV77JoinSafeAnnounced = 1;
        }
        return;
    }

    velocityX = 0.0;
    velocityY = 0.0;
    velocityZ = 0.0;
    onGround = 1;
    g_playerFallDistanceV22 = 0.0;
    if (g_netV60TerrainChunksSkipped > 0 && !anyChunkReady && elapsed >= NETV78_JOIN_NO_TERRAIN_FAIL_SECONDS) {
        NetV60_SetStatus("Server chunk packets arrived but terrain could not be decompressed; check zlib DLL.");
    } else if (g_netV79PreparedChunksThisJoin > 0 && !anyChunkReady) {
        NetV60_SetStatus("Server prepared spawn chunks; waiting for compressed Packet51 terrain...");
    } else {
        NetV60_SetStatus("Downloading server spawn terrain; waiting briefly for center chunk...");
    }
}

static void NetV77_OnAuthoritativeServerPosition(double gx, double gy, double gz)
{
    g_netV77SawServerPosition = 1;
    g_netV77LastServerGX = gx;
    g_netV77LastServerGY = gy;
    g_netV77LastServerGZ = gz;
    velocityX = 0.0;
    velocityY = 0.0;
    velocityZ = 0.0;
    NetV77_CheckJoinHoldRelease();
}

int NetworkV77_ShouldHoldPlayerDuringJoin(void)
{
    return NetworkV78_ShouldHoldPlayerDuringJoin();
}

int NetworkV78_ShouldHoldPlayerDuringJoin(void)
{
    if (!g_networkMultiplayerActive || g_netV60State != 2) { return 0; }
    NetV77_CheckJoinHoldRelease();
    return g_netV77JoinHoldActive ? 1 : 0;
}

static int NetV76_NetworkReadBudgetExhausted(void)
{
    if (g_netV61PacketsThisTick >= NETV61_MAX_PACKETS_PER_TICK) { return 1; }
    if (g_netV61BytesThisTick >= NETV61_MAX_BYTES_PER_TICK) { return 1; }
    /* V79: joining a server should not decompress/rebuild a whole burst in one
       frame.  While the spawn terrain is being accepted, keep the chunk packet
       budget lower; after movement is released, allow the normal V76 budget. */
    if (g_netV77JoinHoldActive && g_netV76ChunkPacketsThisTick >= NETV79_NETWORK_JOIN_CHUNK_BUDGET_WIN98) { return 1; }
    if (g_netV76ChunkPacketsThisTick >= NETV76_MAX_CHUNK_PACKETS_PER_TICK) { return 1; }
    return 0;
}

static void NetV60_ApplyMapChunk(int xPos, int yPos, int zPos, int xSize, int ySize, int zSize, const unsigned char *compressed, long compressedLen)
{
    unsigned long outLen;
    long blockCount;
    long nibbleCount;
    long expected;
    long idx;
    long metaBase;
    long blockLightBase;
    long skyLightBase;
    int lx;
    int ly;
    int lz;
    int localX;
    int localZ;
    int block;
    int meta;
    int bl;
    int sl;
    int gx;
    int gy;
    int gz;
    int anyApplied;
    int haveServerLight;

    if (xSize <= 0 || ySize <= 0 || zSize <= 0 || xSize > 16 || ySize > 128 || zSize > 16) { return; }
    if (yPos < 0 || yPos >= WORLD_Y || yPos + ySize > WORLD_Y) { return; }
    blockCount = (long)xSize * (long)ySize * (long)zSize;
    /* V79: match uploaded Java Packet51MapChunk exactly: new byte[(x*y*z*5)/2].
       Most Beta chunks are even-sized, but using the Java formula prevents false
       bad-chunk skips on partial update boxes. */
    expected = (blockCount * 5L) / 2L;
    nibbleCount = (expected - blockCount) / 3L;
    if (blockCount <= 0 || expected <= 0 || expected > NETV60_MAX_DECOMPRESSED_CHUNK) { return; }
    if (!NetV60_LoadZlib()) {
        g_netV60TerrainChunksSkipped++;
        if (!g_netV60MissingZlibWarned) {
            g_netV60MissingZlibWarned = 1;
            GuiV9_AddChatLine("Multiplayer: no usable zlib1.dll/zlib.dll found in EXE or DLLS folder; server terrain skipped safely.");
        }
        return;
    }
    outLen = (unsigned long)expected;
    if (g_netV60Uncompress(g_netV60ChunkOut, &outLen, compressed, (unsigned long)compressedLen) != 0 || (long)outLen < blockCount) {
        g_netV60TerrainChunksSkipped++;
        if (g_netV60TerrainChunksSkipped < 4) { GuiV9_AddChatLine("Skipped a bad compressed map chunk instead of crashing."); }
        return;
    }

    /* If the first real chunk is far from the default local window, center the
       multiplayer cache on it.  Otherwise player local coordinates can become
       huge after Packet13 and crash render/physics. */
    if (g_netV60TerrainChunksApplied == 0 && !g_netV77SawServerPosition && !g_netV77SawSpawnPacket) {
        NetV68_EnsureWindowForGlobal((double)xPos + 8.0, (double)zPos + 8.0);
    }

    idx = 0;
    metaBase = blockCount;
    blockLightBase = metaBase + nibbleCount;
    skyLightBase = blockLightBase + nibbleCount;
    haveServerLight = ((long)outLen >= skyLightBase + nibbleCount) ? 1 : 0;
    anyApplied = 0;

    /* Uploaded Java reference:
       Packet51MapChunk inflates a byte array sized (x*y*z*5)/2.  World.setChunkData
       then feeds Chunk.setChunkData(), which copies all block ids first, then
       metadata nibbles, then block light nibbles, then sky light nibbles, using
       X/Z/Y column order.  This loop mirrors that order but writes into CloneMC's
       128x128 active multiplayer cache. */
    for (lx = 0; lx < xSize; lx++) {
        for (lz = 0; lz < zSize; lz++) {
            for (ly = 0; ly < ySize; ly++) {
                block = (int)g_netV60ChunkOut[idx];
                meta = 0;
                bl = 0;
                sl = 15;
                if ((long)outLen >= metaBase + nibbleCount) { meta = NetV60_ReadNibbleV68(g_netV60ChunkOut, metaBase, idx, (long)outLen); }
                if (haveServerLight) {
                    bl = NetV60_ReadNibbleV68(g_netV60ChunkOut, blockLightBase, idx, (long)outLen);
                    sl = NetV60_ReadNibbleV68(g_netV60ChunkOut, skyLightBase, idx, (long)outLen);
                }
                gx = xPos + lx;
                gy = yPos + ly;
                gz = zPos + lz;
                localX = gx - worldOriginBlockX;
                localZ = gz - worldOriginBlockZ;
                if (localX >= 0 && localX < WORLD_X && gy >= 0 && gy < WORLD_Y && localZ >= 0 && localZ < WORLD_Z) {
                    world[localX][gy][localZ] = NetV60_ServerBlockToLocal(block);
                    g_blockMeta[localX][gy][localZ] = (unsigned char)(meta & 15);
                    if (haveServerLight) {
                        blockLight[localX][gy][localZ] = (unsigned char)(bl & 15);
                        skyLight[localX][gy][localZ] = (unsigned char)(sl & 15);
                    }
                    anyApplied = 1;
                }
                idx++;
            }
        }
    }

    if (haveServerLight) { g_netV76ServerLightAccepted = 1; }
    else { g_netV76ServerLightMissing = 1; }

    if (anyApplied) {
        NetV77_MarkRemoteChunkDataLocalRange(xPos - worldOriginBlockX, zPos - worldOriginBlockZ,
                                            xPos + xSize - 1 - worldOriginBlockX,
                                            zPos + zSize - 1 - worldOriginBlockZ);
        NetV76_ScheduleRemoteChunkPost(xPos, zPos, xPos + xSize - 1, zPos + zSize - 1);
        NetV77_CheckJoinHoldRelease();
    }
    g_netV60TerrainChunksApplied++;
}

static int NetV62_LoadZlibInflate(void)
{
    if (!NetV60_LoadZlib()) { return 0; }
    if (g_netV62Inflate && g_netV62InflateInit2 && g_netV62InflateEnd && g_netV62ZlibVersion) { return 1; }
    g_netV62ZlibVersion = (NetV62_ZlibVersionProc)GetProcAddress(g_netV60ZlibModule, "zlibVersion");
    g_netV62InflateInit2 = (NetV62_ZlibInflateInit2Proc)GetProcAddress(g_netV60ZlibModule, "inflateInit2_");
    g_netV62Inflate = (NetV62_ZlibInflateProc)GetProcAddress(g_netV60ZlibModule, "inflate");
    g_netV62InflateEnd = (NetV62_ZlibInflateEndProc)GetProcAddress(g_netV60ZlibModule, "inflateEnd");
    return g_netV62ZlibVersion && g_netV62InflateInit2 && g_netV62Inflate && g_netV62InflateEnd;
}


static void NetV71_ClearRemoteEntities(void)
{
    int i;
    for (i = 0; i < NETV71_REMOTE_ENTITY_SLOTS; i++) {
        g_netV71RemoteEntityIds[i] = 0;
        g_netV71RemoteEntityIsPlayer[i] = 0;
        g_netV80RemoteEntityName[i][0] = 0;
        g_netV80RemoteEntityHeldItem[i] = ITEM_NONE;
        g_netV80RemoteEntityHeldDamage[i] = 0;
        if (i < MAX_MOBS) {
            mobs[i].active = 0;
        }
    }
    for (i = 0; i < NETV80_REMOTE_DROPPED_ITEM_SLOTS; i++) {
        g_netV80RemoteDroppedItemEntityIds[i] = 0;
        g_netV80RemoteDroppedItemIndex[i] = -1;
    }
    for (i = 0; i < NETV80_WINDOW_SLOTS; i++) {
        NetV80_ClearItemStack(&g_netV80WindowSlots[i]);
    }
    NetV80_ClearItemStack(&g_netV80CursorStack);
    g_netV80OpenWindowId = -1;
    g_netV80OpenWindowType = 0;
    g_netV80OpenWindowSlotCount = 0;
    g_netV80OpenWindowTitle[0] = 0;
}

static int NetV71_MobTypeFromServerType(int serverType)
{
    if (serverType == 50) { return MOB_CREEPER; }
    if (serverType == 51) { return MOB_SKELETON; }
    if (serverType == 52) { return MOB_SPIDER; }
    if (serverType == 54) { return MOB_ZOMBIE; }
    if (serverType == 55) { return MOB_SLIME; }
    if (serverType == 90) { return MOB_PIG; }
    if (serverType == 91) { return MOB_SHEEP; }
    if (serverType == 92) { return MOB_COW; }
    if (serverType == 93) { return MOB_CHICKEN; }
    if (serverType == 94) { return MOB_SQUID; }
    if (serverType == 95) { return MOB_WOLF; }
    return MOB_ZOMBIE;
}

static int NetV71_FindRemoteEntitySlot(long entityId)
{
    int i;
    for (i = 0; i < NETV71_REMOTE_ENTITY_SLOTS; i++) {
        if (g_netV71RemoteEntityIds[i] == (int)entityId && mobs[i].active) { return i; }
    }
    return -1;
}

int NetworkV80_GetRemoteEntityIdForMobSlot(int slot)
{
    if (slot < 0 || slot >= NETV71_REMOTE_ENTITY_SLOTS) { return 0; }
    if (!mobs[slot].active) { return 0; }
    return g_netV71RemoteEntityIds[slot];
}

static void NetV80_UpdateRemoteEntityNameHeld(long entityId, const char *name, int heldItem, int heldDamage)
{
    int slot;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot < 0 || slot >= NETV71_REMOTE_ENTITY_SLOTS) { return; }
    if (name) {
        strncpy(g_netV80RemoteEntityName[slot], name, NETV80_REMOTE_NAME_CHARS);
        g_netV80RemoteEntityName[slot][NETV80_REMOTE_NAME_CHARS] = 0;
    }
    g_netV80RemoteEntityHeldItem[slot] = (heldItem > 0) ? heldItem : ITEM_NONE;
    g_netV80RemoteEntityHeldDamage[slot] = heldDamage;
}

static int NetV80_FindRemoteDroppedItemSlot(long entityId)
{
    int i;
    for (i = 0; i < NETV80_REMOTE_DROPPED_ITEM_SLOTS; i++) {
        if (g_netV80RemoteDroppedItemEntityIds[i] == (int)entityId) { return i; }
    }
    return -1;
}

static int NetV80_AllocRemoteDroppedItemSlot(long entityId)
{
    int i;
    int slot;
    slot = NetV80_FindRemoteDroppedItemSlot(entityId);
    if (slot >= 0) { return slot; }
    for (i = 0; i < NETV80_REMOTE_DROPPED_ITEM_SLOTS; i++) {
        if (g_netV80RemoteDroppedItemEntityIds[i] == 0) {
            g_netV80RemoteDroppedItemEntityIds[i] = (int)entityId;
            g_netV80RemoteDroppedItemIndex[i] = -1;
            return i;
        }
    }
    return -1;
}

static void NetV80_DestroyRemoteItem(long entityId)
{
    int slot;
    int idx;
    slot = NetV80_FindRemoteDroppedItemSlot(entityId);
    if (slot < 0) { return; }
    idx = g_netV80RemoteDroppedItemIndex[slot];
    if (idx >= 0 && idx < MAX_DROPPED_ITEMS) {
        droppedItems[idx].active = 0;
    }
    g_netV80RemoteDroppedItemEntityIds[slot] = 0;
    g_netV80RemoteDroppedItemIndex[slot] = -1;
}

static void NetV80_SpawnRemotePickup(long entityId, int itemId, int count, int damage, long fixedX, long fixedY, long fixedZ, int motionX, int motionY, int motionZ)
{
    int slot;
    int idx;
    double gx;
    double gy;
    double gz;
    if (itemId <= 0 || count <= 0) { return; }
    gx = (double)fixedX / 32.0;
    gy = (double)fixedY / 32.0;
    gz = (double)fixedZ / 32.0;
    NetV68_EnsureWindowForGlobal(gx, gz);
    slot = NetV80_AllocRemoteDroppedItemSlot(entityId);
    if (slot < 0) { return; }
    idx = AddDroppedItemStackV38(itemId, count, damage, gx - (double)worldOriginBlockX, gy, gz - (double)worldOriginBlockZ,
                                (double)NetV80_ToSignedByte(motionX) / 128.0,
                                (double)NetV80_ToSignedByte(motionY) / 128.0,
                                (double)NetV80_ToSignedByte(motionZ) / 128.0);
    if (idx >= 0 && idx < MAX_DROPPED_ITEMS) {
        droppedItems[idx].vx = (double)NetV80_ToSignedByte(motionX) / 128.0;
        droppedItems[idx].vy = (double)NetV80_ToSignedByte(motionY) / 128.0;
        droppedItems[idx].vz = (double)NetV80_ToSignedByte(motionZ) / 128.0;
        droppedItems[idx].pickupDelay = 0.20;
        g_netV80RemoteDroppedItemIndex[slot] = idx;
    }
}

static void NetV80_CollectRemoteEntity(long collectedEntityId, long collectorEntityId)
{
    int slot;
    int idx;
    slot = NetV80_FindRemoteDroppedItemSlot(collectedEntityId);
    if (slot >= 0) {
        idx = g_netV80RemoteDroppedItemIndex[slot];
        if (idx >= 0 && idx < MAX_DROPPED_ITEMS && droppedItems[idx].active) {
            SpawnPickupFxV38(&droppedItems[idx]);
            droppedItems[idx].active = 0;
        }
        g_netV80RemoteDroppedItemEntityIds[slot] = 0;
        g_netV80RemoteDroppedItemIndex[slot] = -1;
        return;
    }
    (void)collectorEntityId;
    NetV71_DestroyRemoteEntity(collectedEntityId);
}

static void NetV80_ApplyEntityVelocity(long entityId, int vx, int vy, int vz)
{
    int slot;
    int itemSlot;
    int idx;
    double mx;
    double my;
    double mz;
    mx = (double)((short)vx) / 8000.0;
    my = (double)((short)vy) / 8000.0;
    mz = (double)((short)vz) / 8000.0;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot >= 0 && slot < MAX_MOBS) {
        mobs[slot].vx = mx;
        mobs[slot].vy = my;
        mobs[slot].vz = mz;
    }
    itemSlot = NetV80_FindRemoteDroppedItemSlot(entityId);
    if (itemSlot >= 0) {
        idx = g_netV80RemoteDroppedItemIndex[itemSlot];
        if (idx >= 0 && idx < MAX_DROPPED_ITEMS) {
            droppedItems[idx].vx = mx;
            droppedItems[idx].vy = my;
            droppedItems[idx].vz = mz;
        }
    }
}

static void NetV80_ApplyEntityStatus(long entityId, int status)
{
    int slot;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot < 0 || slot >= MAX_MOBS) { return; }
    if (status == 2) {
        mobs[slot].hurtTime = 0.55;
    } else if (status == 3) {
        mobs[slot].health = 0;
        mobs[slot].deathTime = 1.40;
    } else if (status == 4) {
        mobs[slot].attackTimer = 0.35;
    }
}

static void NetV80_SetPlayerInventorySlot(int slot, const InventorySlot *stack)
{
    InventorySlot empty;
    const InventorySlot *src;
    NetV80_ClearItemStack(&empty);
    src = stack ? stack : &empty;
    if (slot >= 36 && slot < 45) {
        hotbar[slot - 36] = *src;
    } else if (slot >= 9 && slot < 36) {
        inventory[slot - 9] = *src;
    } else if (slot >= 5 && slot < 9) {
        g_armorSlotsV6[slot - 5] = *src;
    } else if (slot >= 1 && slot < 5) {
        craftGrid[slot - 1] = *src;
    } else if (slot == 0) {
        craftResult = *src;
    }
}

static void NetV80_SetWindowSlot(int windowId, int slot, const InventorySlot *stack)
{
    InventorySlot empty;
    const InventorySlot *src;
    NetV80_ClearItemStack(&empty);
    src = stack ? stack : &empty;
    if (windowId == -1) {
        g_netV80CursorStack = *src;
        return;
    }
    if (windowId == 0) {
        NetV80_SetPlayerInventorySlot(slot, src);
        return;
    }
    if (windowId == g_netV80OpenWindowId && slot >= 0 && slot < NETV80_WINDOW_SLOTS) {
        g_netV80WindowSlots[slot] = *src;
    }
}

static void NetV80_OpenWindow(int windowId, int windowType, const char *title, int slots)
{
    int i;
    if (slots < 0) { slots = 0; }
    if (slots > NETV80_WINDOW_SLOTS) { slots = NETV80_WINDOW_SLOTS; }
    g_netV80OpenWindowId = windowId;
    g_netV80OpenWindowType = windowType;
    g_netV80OpenWindowSlotCount = slots;
    if (title) {
        strncpy(g_netV80OpenWindowTitle, title, sizeof(g_netV80OpenWindowTitle) - 1);
        g_netV80OpenWindowTitle[sizeof(g_netV80OpenWindowTitle) - 1] = 0;
    } else {
        g_netV80OpenWindowTitle[0] = 0;
    }
    for (i = 0; i < NETV80_WINDOW_SLOTS; i++) { NetV80_ClearItemStack(&g_netV80WindowSlots[i]); }
    if (windowType == 1) { craftingOpen = 1; }
    GuiV9_AddChatLine("Server opened a container window; slot sync is active.");
}

static void NetV80_CloseWindow(int windowId)
{
    int i;
    if (windowId == g_netV80OpenWindowId || windowId == 0) {
        g_netV80OpenWindowId = -1;
        g_netV80OpenWindowType = 0;
        g_netV80OpenWindowSlotCount = 0;
        g_netV80OpenWindowTitle[0] = 0;
        for (i = 0; i < NETV80_WINDOW_SLOTS; i++) { NetV80_ClearItemStack(&g_netV80WindowSlots[i]); }
        if (craftingOpen && g_containerModeV5 == CONTAINER_NONE_V5) { craftingOpen = 0; }
    }
}

static int NetV71_AllocRemoteEntitySlot(long entityId)
{
    int i;
    int slot;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot >= 0) { return slot; }
    for (i = 0; i < NETV71_REMOTE_ENTITY_SLOTS; i++) {
        if (!mobs[i].active) {
            g_netV71RemoteEntityIds[i] = (int)entityId;
            return i;
        }
    }
    /* Reuse slot zero as a bounded fallback instead of overflowing arrays. */
    g_netV71RemoteEntityIds[0] = (int)entityId;
    return 0;
}

static void NetV71_SetRemoteEntity(long entityId, int mobType, int isPlayer, long fixedX, long fixedY, long fixedZ, int yawByte)
{
    int slot;
    Mob *m;
    double gx;
    double gy;
    double gz;
    slot = NetV71_AllocRemoteEntitySlot(entityId);
    if (slot < 0 || slot >= MAX_MOBS) { return; }
    gx = (double)fixedX / 32.0;
    gy = (double)fixedY / 32.0;
    gz = (double)fixedZ / 32.0;
    NetV68_EnsureWindowForGlobal(gx, gz);
    m = &mobs[slot];
    memset(m, 0, sizeof(Mob));
    m->active = 1;
    m->type = mobType;
    m->health = 20;
    m->angry = isPlayer ? 2 : 0;
    m->x = gx - (double)worldOriginBlockX;
    m->y = gy;
    m->z = gz - (double)worldOriginBlockZ;
    m->prevX = m->x;
    m->prevY = m->y;
    m->prevZ = m->z;
    m->yaw = (double)((yawByte & 255) * 360) / 256.0;
    m->prevYaw = m->yaw;
    m->renderYawOffset = m->yaw;
    m->prevRenderYawOffset = m->yaw;
    m->targetKind = MOB_TARGET_NONE;
    m->spawnGraceTimer = 9999.0;
    g_netV71RemoteEntityIsPlayer[slot] = isPlayer ? 1 : 0;
    g_netV80RemoteEntityName[slot][0] = 0;
    g_netV80RemoteEntityHeldItem[slot] = ITEM_NONE;
    g_netV80RemoteEntityHeldDamage[slot] = 0;
}

static void NetV71_MoveRemoteEntityRelative(long entityId, int dxByte, int dyByte, int dzByte, int hasLook, int yawByte, int pitchByte)
{
    int slot;
    Mob *m;
    double dx;
    double dy;
    double dz;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot < 0) { return; }
    m = &mobs[slot];
    m->prevX = m->x;
    m->prevY = m->y;
    m->prevZ = m->z;
    m->prevYaw = m->yaw;
    dx = (double)((signed char)dxByte) / 32.0;
    dy = (double)((signed char)dyByte) / 32.0;
    dz = (double)((signed char)dzByte) / 32.0;
    m->x += dx;
    m->y += dy;
    m->z += dz;
    m->vx = dx * 20.0;
    m->vy = dy * 20.0;
    m->vz = dz * 20.0;
    if (hasLook) {
        m->yaw = (double)((yawByte & 255) * 360) / 256.0;
        m->renderYawOffset = m->yaw;
    }
    m->animWalk += sqrt(dx * dx + dz * dz) * 2.7;
}

static void NetV71_TeleportRemoteEntity(long entityId, long fixedX, long fixedY, long fixedZ, int yawByte, int pitchByte)
{
    int slot;
    Mob *m;
    double gx;
    double gy;
    double gz;
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot < 0) { return; }
    gx = (double)fixedX / 32.0;
    gy = (double)fixedY / 32.0;
    gz = (double)fixedZ / 32.0;
    NetV68_EnsureWindowForGlobal(gx, gz);
    m = &mobs[slot];
    m->prevX = m->x;
    m->prevY = m->y;
    m->prevZ = m->z;
    m->prevYaw = m->yaw;
    m->x = gx - (double)worldOriginBlockX;
    m->y = gy;
    m->z = gz - (double)worldOriginBlockZ;
    m->yaw = (double)((yawByte & 255) * 360) / 256.0;
    m->renderYawOffset = m->yaw;
}

static void NetV71_DestroyRemoteEntity(long entityId)
{
    int slot;
    NetV80_DestroyRemoteItem(entityId);
    slot = NetV71_FindRemoteEntitySlot(entityId);
    if (slot >= 0 && slot < MAX_MOBS) {
        mobs[slot].active = 0;
        g_netV71RemoteEntityIds[slot] = 0;
        g_netV71RemoteEntityIsPlayer[slot] = 0;
        g_netV80RemoteEntityName[slot][0] = 0;
        g_netV80RemoteEntityHeldItem[slot] = ITEM_NONE;
        g_netV80RemoteEntityHeldDamage[slot] = 0;
    }
}

static int NetV62Classic_InflateGzip(unsigned char *out, unsigned long outCap, unsigned long *outLen)
{
    NetV62_ZStream zs;
    int rc;
    if (!NetV62_LoadZlibInflate()) { return 0; }
    memset(&zs, 0, sizeof(zs));
    zs.next_in = g_netV62ClassicCompressed;
    zs.avail_in = (unsigned int)g_netV62ClassicCompressedLen;
    zs.next_out = out;
    zs.avail_out = (unsigned int)outCap;
    rc = g_netV62InflateInit2(&zs, 15 + 32, g_netV62ZlibVersion(), sizeof(NetV62_ZStream));
    if (rc != 0) { return 0; }
    rc = g_netV62Inflate(&zs, NETV62_Z_FINISH);
    g_netV62InflateEnd(&zs);
    if (rc != NETV62_Z_STREAM_END) { return 0; }
    *outLen = zs.total_out;
    return 1;
}

static int NetV62Classic_ApplyLevel(int sx, int sy, int sz)
{
    unsigned long outLen;
    long expected;
    long count;
    long idx;
    int x;
    int y;
    int z;
    int block;
    if (sx <= 0 || sy <= 0 || sz <= 0 || sx > WORLD_X || sy > WORLD_Y || sz > WORLD_Z) {
        NetV60_Fail("Classic level size is larger than this Win98 build can hold.");
        return 0;
    }
    if (g_netV62ClassicCompressedLen <= 0) {
        NetV60_Fail("Classic server sent an empty level.");
        return 0;
    }
    outLen = 0;
    if (!NetV62Classic_InflateGzip(g_netV62ClassicLevelOut, (unsigned long)NETV62_CLASSIC_MAX_LEVEL_OUT, &outLen)) {
        NetV60_Fail("Could not decompress Classic/ClassiCube level. Put a real zlib1.dll or zlib.dll next to the EXE.");
        return 0;
    }
    expected = (long)sx * (long)sy * (long)sz;
    if (outLen < 4 || expected <= 0 || expected > (long)WORLD_X * (long)WORLD_Y * (long)WORLD_Z) {
        NetV60_Fail("Invalid Classic level size from server.");
        return 0;
    }
    count = ((long)g_netV62ClassicLevelOut[0] << 24) | ((long)g_netV62ClassicLevelOut[1] << 16) | ((long)g_netV62ClassicLevelOut[2] << 8) | (long)g_netV62ClassicLevelOut[3];
    if (count < expected || outLen < 4 + expected) {
        NetV60_Fail("Classic level data was truncated.");
        return 0;
    }
    currentWorldSlot = -1;
    g_worldSizeBlocks = WORLD_SIZE_INFINITE;
    g_startFromSavedPosition = 0;
    g_networkMultiplayerActive = 1;
    g_netV62ClassicLevelX = sx;
    g_netV62ClassicLevelY = sy;
    g_netV62ClassicLevelZ = sz;
    NetV70_PrepareRemoteClientWorld();
    worldOriginBlockX = 0;
    worldOriginBlockZ = 0;
    WorldGenV70_ClearWorldArraysNoTerrain();
    g_netV69RemoteBatchApply = 1;
    for (y = 0; y < sy; y++) {
        for (z = 0; z < sz; z++) {
            for (x = 0; x < sx; x++) {
                idx = 4L + ((long)y * (long)sx * (long)sz) + ((long)z * (long)sx) + (long)x;
                block = (int)g_netV62ClassicLevelOut[idx];
                block = NetV60_ServerBlockToLocal(block);
                world[x][y][z] = block;
                g_blockMeta[x][y][z] = 0;
            }
        }
    }
    g_netV69RemoteBatchApply = 0;
    NetV68_FinishRemoteChunkApply();
    EnterGame();
    playerX = (double)(sx / 2);
    playerY = (double)(sy > 66 ? 66 : (sy / 2));
    playerZ = (double)(sz / 2);
    GuiV9_AddChatLine("Connected to Classic/ClassiCube protocol. Username is separate from server address.");
    NetV60_SetStatus("Classic/ClassiCube level loaded.");
    return 1;
}

static int NetV62Classic_HandlePacket(const unsigned char *buf, int len, int *consumed)
{
    int op;
    int off;
    int version;
    int chunkLen;
    int percent;
    int x;
    int y;
    int z;
    int block;
    int pid;
    int yawByte;
    int pitchByte;
    long lv;
    char text[256];
    if (len <= 0) { return 0; }
    op = (int)buf[0];
    off = 1;
    *consumed = 0;
    switch (op) {
    case 0:
        if (len < 1 + 1 + 64 + 64 + 1) { return 0; }
        version = (int)buf[off++];
        NetV62Classic_ReadFixedString(buf, &off, text, sizeof(text));
        NetV62Classic_ReadFixedString(buf, &off, text, sizeof(text));
        off++;
        if (version != 7) { return -1; }
        *consumed = off;
        NetV60_SetStatus("Classic/ClassiCube server accepted username. Waiting for level...");
        return 1;
    case 1:
        *consumed = 1;
        return 1;
    case 2:
        g_netV62ClassicCompressedLen = 0L;
        *consumed = 1;
        NetV60_SetStatus("Downloading Classic/ClassiCube level...");
        GuiV9_EnterDownloadTerrain();
        return 1;
    case 3:
        if (len < 1 + 2 + NETV62_CLASSIC_LEVEL_CHUNK + 1) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &chunkLen)) { return 0; }
        if (chunkLen < 0 || chunkLen > NETV62_CLASSIC_LEVEL_CHUNK) { return -1; }
        if (g_netV62ClassicCompressedLen + chunkLen > NETV62_CLASSIC_MAX_COMPRESSED_LEVEL) { return -1; }
        memcpy(g_netV62ClassicCompressed + g_netV62ClassicCompressedLen, buf + off, chunkLen);
        g_netV62ClassicCompressedLen += chunkLen;
        off += NETV62_CLASSIC_LEVEL_CHUNK;
        percent = (int)buf[off++];
        g_guiV9DownloadProgress = percent;
        *consumed = off;
        return 1;
    case 4:
        if (!NetV60_ReadU16(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &z)) { return 0; }
        *consumed = off;
        return NetV62Classic_ApplyLevel(x, y, z) ? 1 : -1;
    case 6:
        if (!NetV60_ReadU16(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &block)) { return 0; }
        if (x >= 0 && x < WORLD_X && y >= 0 && y < WORLD_Y && z >= 0 && z < WORLD_Z) { NetV60_ApplyBlockGlobal(x + worldOriginBlockX, y, z + worldOriginBlockZ, block, 0); }
        *consumed = off;
        return 1;
    case 7:
        if (len < 1 + 1 + 64 + 2 + 2 + 2 + 1 + 1) { return 0; }
        *consumed = 1 + 1 + 64 + 2 + 2 + 2 + 1 + 1;
        return 1;
    case 8:
        if (!NetV60_ReadU8(buf, len, &off, &pid)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        if (pid == 255) {
            playerX = (double)x / 32.0;
            playerY = (double)y / 32.0;
            playerZ = (double)z / 32.0;
            yaw = (double)yawByte * 360.0 / 256.0;
            pitch = (double)pitchByte * 360.0 / 256.0;
        }
        *consumed = off;
        return 1;
    case 9:
        if (len < 1 + 1 + 1 + 1 + 1 + 1 + 1) { return 0; }
        *consumed = 7;
        return 1;
    case 10:
        if (len < 1 + 1 + 1 + 1 + 1) { return 0; }
        *consumed = 5;
        return 1;
    case 11:
        if (len < 1 + 1 + 1 + 1) { return 0; }
        *consumed = 4;
        return 1;
    case 12:
        if (len < 2) { return 0; }
        *consumed = 2;
        return 1;
    case 13:
        if (len < 1 + 1 + 64) { return 0; }
        off++; /* player id */
        NetV62Classic_ReadFixedString(buf, &off, text, sizeof(text));
        NetV61_SanitizeDisplayText(text);
        GuiV9_AddChatLine(text);
        *consumed = off;
        return 1;
    case 14:
        if (len < 1 + 64) { return 0; }
        NetV62Classic_ReadFixedString(buf, &off, text, sizeof(text));
        NetV61_SanitizeDisplayText(text);
        *consumed = off;
        NetV60_Fail(text);
        return 1;
    case 15:
        if (len < 2) { return 0; }
        *consumed = 2;
        return 1;
    case 16:
        if (len < 1 + 64 + 2) { return 0; }
        NetV62Classic_ReadFixedString(buf, &off, text, sizeof(text));
        if (!NetV60_ReadU16(buf, len, &off, &g_netV62ClassicCpeEntriesLeft)) { return 0; }
        if (g_netV62ClassicCpeEntriesLeft < 0 || g_netV62ClassicCpeEntriesLeft > 256) { return -1; }
        *consumed = off;
        return 1;
    case 17:
        if (len < 1 + 64 + 4) { return 0; }
        off += 64;
        if (!NetV60_ReadI32(buf, len, &off, &lv)) { return 0; }
        if (g_netV62ClassicCpeEntriesLeft > 0) { g_netV62ClassicCpeEntriesLeft--; }
        *consumed = off;
        return 1;
    default:
        sprintf(text, "Unsupported Classic/ClassiCube packet id %d; disconnected to protect packet sync.", op);
        NetV60_Fail(text);
        return -1;
    }
}


static void NetV68_ClearRemoteWorldArrays(void)
{
    WorldGenV70_ClearWorldArraysNoTerrain();
    NetV77_ResetRemoteChunkDataFlags();
    RebuildColumnTops();
    ComputeLegacyLighting();
    InvalidateAllTerrainChunkMeshes();
}

static void NetV68_RecenterRemoteWindow(double gx, double gz)
{
    int centerChunkX;
    int centerChunkZ;
    centerChunkX = FloorDivInt((int)floor(gx), CHUNK_SIZE);
    centerChunkZ = FloorDivInt((int)floor(gz), CHUNK_SIZE);
    worldCenterChunkX = centerChunkX;
    worldCenterChunkZ = centerChunkZ;
    worldOriginBlockX = (worldCenterChunkX - WORLD_CHUNKS_X / 2) * CHUNK_SIZE;
    worldOriginBlockZ = (worldCenterChunkZ - WORLD_CHUNKS_Z / 2) * CHUNK_SIZE;
    NetV68_ClearRemoteWorldArrays();
    if (g_networkMultiplayerActive && g_netV62ProtocolMode == NETV62_PROTOCOL_BETA173) {
        g_netV77JoinHoldActive = 1;
        g_netV77JoinSafeAnnounced = 0;
        g_netV77JoinHoldStartTime = NetV60_TimeSeconds();
        g_netV78JoinReleasedByTimeout = 0;
        g_netV78JoinCenterReadyOnce = 0;
        velocityX = 0.0;
        velocityY = 0.0;
        velocityZ = 0.0;
        onGround = 1;
    }
}

static void NetV68_EnsureWindowForGlobal(double gx, double gz)
{
    if (gx >= (double)(worldOriginBlockX + 4) && gx < (double)(worldOriginBlockX + WORLD_X - 4) &&
        gz >= (double)(worldOriginBlockZ + 4) && gz < (double)(worldOriginBlockZ + WORLD_Z - 4)) {
        return;
    }
    NetV68_RecenterRemoteWindow(gx, gz);
}

static void NetV68_FinishRemoteChunkApply(void)
{
    /* V76: kept for older call sites.  The expensive V72 behavior rebuilt all
       column tops, recomputed all lighting, and invalidated every display list
       after each server chunk.  Multiplayer join bursts now schedule dirty
       ranges and flush them once per network tick. */
    NetV76_FinishDeferredRemotePost();
}

static void NetV70_PrepareRemoteClientWorld(void)
{
    /* Multiplayer worlds must be server-authoritative.  Do not call GameInit(),
       because GameInit runs singleplayer worldgen and spawn recovery, which was
       causing pad/ocean terrain to appear before or over server chunks. */
    currentWorldSlot = -1;
    g_startFromSavedPosition = 0;
    g_networkMultiplayerActive = 1;
    g_worldSizeBlocks = WORLD_SIZE_INFINITE;
    NetV71_ClearRemoteEntities();
    g_netV77SawSpawnPacket = 0;
    g_netV77SawServerPosition = 0;
    g_netV77JoinHoldActive = 0;
    worldCenterChunkX = 0;
    worldCenterChunkZ = 0;
    worldOriginBlockX = -(WORLD_X / 2);
    worldOriginBlockZ = -(WORLD_Z / 2);
    WorldGenV70_ClearWorldArraysNoTerrain();
    playerX = (double)(WORLD_X / 2) + 0.5;
    playerY = (double)(GEN_WATER_LEVEL + 8);
    playerZ = (double)(WORLD_Z / 2) + 0.5;
    velocityX = 0.0;
    velocityY = 0.0;
    velocityZ = 0.0;
    onGround = 0;
    playerHealth = MAX_HEALTH;
    playerPrevHealth = MAX_HEALTH;
    inventoryOpen = 0;
    craftingOpen = 0;
    RebuildColumnTops();
    ComputeLegacyLighting();
    InvalidateAllTerrainChunkMeshes();
    NetV77_BeginJoinHold();
}

static void NetV60_StartWorldFromLogin(unsigned long seedHi, unsigned long seedLo, int dimension, int entityId)
{
    g_netV60EntityId = entityId;
    g_netV60Dimension = dimension;
    g_netV60SawLogin = 1;
    g_networkMultiplayerActive = 1;
    currentWorldSlot = -1;
    g_worldSeed = (int)(seedLo ^ seedHi ^ 0x5f3759dfUL);
    g_worldSizeBlocks = WORLD_SIZE_INFINITE;
    g_startFromSavedPosition = 0;
    NetV60_SetStatus("Connected. Waiting for server-owned terrain...");
    GuiV9_EnterDownloadTerrain();
    NetV70_PrepareRemoteClientWorld();
    EnterGame();
    GuiV9_AddChatLine("Connected to Beta 1.7.3 server protocol. Waiting for authoritative server chunks/position.");
    if (!NetV60_LoadZlib()) {
        GuiV9_AddChatLine("Install a real zlib1.dll/zlib.dll beside the EXE for exact server chunk terrain loading.");
    }
}

static int NetV60_HandlePacket(const unsigned char *buf, int len, int *consumed)
{
    int op;
    int off;
    int rc;
    int b;
    int b2;
    int b3;
    int chars;
    int xSize;
    int ySize;
    int zSize;
    int yByte;
    int metadata;
    int side;
    int count;
    int i;
    int id;
    int dim;
    int localX;
    int localY;
    int localZ;
    int type;
    int health;
    int coord;
    int blockType;
    int yawByte;
    int pitchByte;
    int currentItem;
    long x;
    long y;
    long z;
    long chunkLen;
    long entityId;
    long protocolOrEntity;
    unsigned long seedHi;
    unsigned long seedLo;
    unsigned long timeHi;
    unsigned long timeLo;
    double dx;
    double dy;
    double dz;
    double stance;
    float fyaw;
    float fpitch;
    char text[256];
    InventorySlot stack;
    if (len <= 0) { return 0; }
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) { return NetV62Classic_HandlePacket(buf, len, consumed); }
    op = (int)buf[0];
    off = 1;
    *consumed = 0;
    switch (op) {
    case 0:
        *consumed = 1;
        return 1;
    case 1:
        if (!NetV60_ReadI32(buf, len, &off, &protocolOrEntity)) { return 0; }
        rc = NetV60_ReadString(buf, len, &off, 16, text, sizeof(text));
        if (rc <= 0) { return rc; }
        if (!NetV60_ReadU64(buf, len, &off, &seedHi, &seedLo)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &dim)) { return 0; }
        *consumed = off;
        NetV60_StartWorldFromLogin(seedHi, seedLo, dim, (int)protocolOrEntity);
        return 1;
    case 2:
        rc = NetV60_ReadString(buf, len, &off, 32, text, sizeof(text));
        if (rc <= 0) { return rc; }
        *consumed = off;
        if (strcmp(text, "-") != 0) {
            GuiV9_AddChatLine("Server requested old online-mode join token; sending offline-compatible login.");
        }
        NetV60_SendLogin(NetworkV62_GetUsername());
        return 1;
    case 3:
        rc = NetV60_ReadString(buf, len, &off, NETV61_MAX_CHAT_CHARS, text, sizeof(text));
        if (rc <= 0) { return rc; }
        NetV61_SanitizeDisplayText(text);
        *consumed = off;
        GuiV9_AddChatLine(text);
        return 1;
    case 4:
        if (!NetV60_ReadU64(buf, len, &off, &timeHi, &timeLo)) { return 0; }
        g_worldTimeSeconds = (double)(timeLo % 24000UL) / 24000.0 * DAY_LENGTH_SECONDS;
        *consumed = off;
        return 1;
    case 5:
        /* V80: Java NetClientHandler.handlePlayerInventory.  Packet5 is
           entity outfit state: int entityID, short slot, short itemID,
           short itemDamage.  Slot 0 is held item for EntityOtherPlayerMP;
           slots 1-4 are armor. */
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &side)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &blockType)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &metadata)) { return 0; }
        if (side == 0) {
            NetV80_UpdateRemoteEntityNameHeld(entityId, NULL, blockType, metadata);
        }
        *consumed = off;
        return 1;
    case 6:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        g_worldSpawnGlobalX = (double)x + 0.5;
        g_worldSpawnY = (double)y;
        g_worldSpawnGlobalZ = (double)z + 0.5;
        g_netV77SawSpawnPacket = 1;
        if (!g_netV77SawServerPosition && g_netV60TerrainChunksApplied == 0) {
            NetV68_EnsureWindowForGlobal(g_worldSpawnGlobalX, g_worldSpawnGlobalZ);
        }
        *consumed = off;
        return 1;
    case 8:
        if (!NetV60_ReadI16(buf, len, &off, &health)) { return 0; }
        if (health < 0) { health = 0; }
        if (health > MAX_HEALTH) { health = MAX_HEALTH; }
        playerHealth = health;
        if (playerHealth <= 0) { EnterDeathScreen(); }
        *consumed = off;
        return 1;
    case 9:
        if (!NetV60_ReadU8(buf, len, &off, &dim)) { return 0; }
        g_netV60Dimension = dim;
        *consumed = off;
        return 1;
    case 10:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        *consumed = off;
        return 1;
    case 11:
        if (!NetV60_ReadDouble(buf, len, &off, &dx)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &dy)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &stance)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &dz)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (!NetV61_ValidateServerCorrection(dx, dy, dz)) { return -1; }
        NetV68_EnsureWindowForGlobal(dx, dz);
        playerX = dx - (double)worldOriginBlockX;
        playerY = dy;
        playerZ = dz - (double)worldOriginBlockZ;
        onGround = b ? 1 : 0;
        NetV77_OnAuthoritativeServerPosition(dx, dy, dz);
        NetV60_SendPacket11(dx, playerY, playerY + EYE_HEIGHT, dz);
        *consumed = off;
        return 1;
    case 12:
        if (!NetV60_ReadFloat(buf, len, &off, &fyaw)) { return 0; }
        if (!NetV60_ReadFloat(buf, len, &off, &fpitch)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (fpitch < -180.0f || fpitch > 180.0f || fyaw < -1080.0f || fyaw > 1080.0f) { return -1; }
        yaw = (double)fyaw;
        pitch = (double)fpitch;
        onGround = b ? 1 : 0;
        NetV60_SendPacket12(fyaw, fpitch);
        *consumed = off;
        return 1;
    case 13:
        if (!NetV60_ReadDouble(buf, len, &off, &dx)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &dy)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &stance)) { return 0; }
        if (!NetV60_ReadDouble(buf, len, &off, &dz)) { return 0; }
        if (!NetV60_ReadFloat(buf, len, &off, &fyaw)) { return 0; }
        if (!NetV60_ReadFloat(buf, len, &off, &fpitch)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (!NetV61_ValidateServerCorrection(dx, dy, dz)) { return -1; }
        if (fpitch < -180.0f || fpitch > 180.0f || fyaw < -1080.0f || fyaw > 1080.0f) { return -1; }
        NetV68_EnsureWindowForGlobal(dx, dz);
        playerX = dx - (double)worldOriginBlockX;
        playerY = dy;
        playerZ = dz - (double)worldOriginBlockZ;
        yaw = (double)fyaw;
        pitch = (double)fpitch;
        onGround = b ? 1 : 0;
        NetV77_OnAuthoritativeServerPosition(dx, dy, dz);
        NetV60_SendPacket13(dx, playerY, playerY + EYE_HEIGHT, dz, fyaw, fpitch);
        *consumed = off;
        return 1;
    case 16:
        if (off + 2 > len) { return 0; }
        *consumed = off + 2;
        return 1;
    case 17:
        if (off + 14 > len) { return 0; }
        *consumed = off + 14;
        return 1;
    case 18:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (b == 1) {
            i = NetV71_FindRemoteEntitySlot(entityId);
            if (i >= 0 && i < MAX_MOBS) { mobs[i].attackTimer = 0.35; }
        } else if (b == 2) {
            NetV80_ApplyEntityStatus(entityId, 2);
        }
        *consumed = off;
        return 1;
    case 20:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        rc = NetV60_ReadString(buf, len, &off, 16, text, sizeof(text));
        if (rc <= 0) { return rc; }
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &currentItem)) { return 0; }
        NetV71_SetRemoteEntity(entityId, MOB_ZOMBIE, 1, x, y, z, yawByte);
        NetV80_UpdateRemoteEntityNameHeld(entityId, text, currentItem, 0);
        *consumed = off;
        return 1;
    case 21:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &blockType)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &count)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &metadata)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b2)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b3)) { return 0; }
        NetV80_SpawnRemotePickup(entityId, blockType, count, metadata, x, y, z, b, b2, b3);
        *consumed = off;
        return 1;
    case 22:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        NetV80_CollectRemoteEntity(x, y);
        *consumed = off;
        return 1;
    case 23:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &type)) { return 0; }
        if (off + 12 > len) { return 0; }
        off += 12;
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (x > 0) {
            if (off + 6 > len) { return 0; }
            off += 6;
        }
        *consumed = off;
        return 1;
    case 24:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &type)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        rc = NetV60_SkipMetadata(buf, len, &off);
        if (rc <= 0) { return rc; }
        NetV71_SetRemoteEntity(entityId, NetV71_MobTypeFromServerType(type), 0, x, y, z, yawByte);
        *consumed = off;
        return 1;
    case 25:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        rc = NetV60_SkipString(buf, len, &off, 13);
        if (rc <= 0) { return rc; }
        if (off + 16 > len) { return 0; }
        *consumed = off + 16;
        return 1;
    case 28:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &b)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &b2)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &b3)) { return 0; }
        NetV80_ApplyEntityVelocity(entityId, b, b2, b3);
        *consumed = off;
        return 1;
    case 29:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        NetV71_DestroyRemoteEntity(entityId);
        *consumed = off;
        return 1;
    case 30:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        *consumed = off;
        return 1;
    case 31:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b2)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b3)) { return 0; }
        NetV71_MoveRemoteEntityRelative(entityId, b, b2, b3, 0, 0, 0);
        *consumed = off;
        return 1;
    case 32:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        NetV71_MoveRemoteEntityRelative(entityId, 0, 0, 0, 1, yawByte, pitchByte);
        *consumed = off;
        return 1;
    case 33:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b2)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b3)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        NetV71_MoveRemoteEntityRelative(entityId, b, b2, b3, 1, yawByte, pitchByte);
        *consumed = off;
        return 1;
    case 34:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &y)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yawByte)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &pitchByte)) { return 0; }
        NetV71_TeleportRemoteEntity(entityId, x, y, z, yawByte, pitchByte);
        *consumed = off;
        return 1;
    case 38:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        NetV80_ApplyEntityStatus(entityId, b);
        *consumed = off;
        return 1;
    case 39:
        if (off + 8 > len) { return 0; }
        *consumed = off + 8;
        return 1;
    case 40:
        if (!NetV60_ReadI32(buf, len, &off, &entityId)) { return 0; }
        rc = NetV60_SkipMetadata(buf, len, &off);
        if (rc <= 0) { return rc; }
        *consumed = off;
        return 1;
    case 50:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        if (b) {
            NetV79_EnsureWindowForIncomingTerrain((int)x * CHUNK_SIZE, (int)z * CHUNK_SIZE);
            NetV79_PrepareRemoteChunkGlobal((int)x, (int)z);
        } else {
            NetV76_ClearRemoteChunkIfLocal((int)x, (int)z);
        }
        *consumed = off;
        return 1;
    case 51:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI16(buf, len, &off, &yByte)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &xSize)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &ySize)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &zSize)) { return 0; }
        xSize++;
        ySize++;
        zSize++;
        if (xSize < 1 || xSize > 16 || ySize < 1 || ySize > 128 || zSize < 1 || zSize > 16) { return -1; }
        if (!NetV61_IsReasonableCoordLong(x) || !NetV61_IsReasonableCoordLong(z)) { return -1; }
        if (!NetV60_ReadI32(buf, len, &off, &chunkLen)) { return 0; }
        if (chunkLen < 0 || chunkLen > NETV60_MAX_PACKET_CHUNK) { return -1; }
        if (off + chunkLen > len) { return 0; }
        NetV79_EnsureWindowForIncomingTerrain((int)x, (int)z);
        NetV60_ApplyMapChunk((int)x, yByte, (int)z, xSize, ySize, zSize, buf + off, chunkLen);
        g_netV76ChunkPacketsThisTick++;
        off += (int)chunkLen;
        *consumed = off;
        return 1;
    case 52:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU16(buf, len, &off, &count)) { return 0; }
        if (count < 0 || count > 4096) { return -1; }
        if (off + count * 4 > len) { return 0; }
        g_netV69RemoteBatchApply = 1;
        for (i = 0; i < count; i++) {
            coord = ((int)buf[off + i * 2] << 8) | (int)buf[off + i * 2 + 1];
            localX = (coord >> 12) & 15;
            localZ = (coord >> 8) & 15;
            localY = coord & 255;
            blockType = (int)buf[off + count * 2 + i];
            metadata = (int)buf[off + count * 3 + i];
            if (NetV61_IsReasonableCoordLong(x) && NetV61_IsReasonableCoordLong(z) && localY >= 0 && localY < WORLD_Y) {
                NetV60_ApplyBlockGlobal((int)x * 16 + localX, localY, (int)z * 16 + localZ, blockType, metadata);
            }
        }
        g_netV69RemoteBatchApply = 0;
        NetV76_ScheduleRemoteChunkPost((int)x * 16, (int)z * 16, (int)x * 16 + 15, (int)z * 16 + 15);
        off += count * 4;
        *consumed = off;
        return 1;
    case 53:
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &yByte)) { return 0; }
        if (!NetV60_ReadI32(buf, len, &off, &z)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &blockType)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &metadata)) { return 0; }
        if (!NetV61_IsReasonableCoordLong(x) || !NetV61_IsReasonableCoordLong(z)) { return -1; }
        NetV60_ApplyBlockGlobal((int)x, yByte, (int)z, blockType, metadata);
        *consumed = off;
        return 1;
    case 54:
        if (off + 12 > len) { return 0; }
        *consumed = off + 12;
        return 1;
    case 60:
        if (off + 32 > len) { return 0; }
        off += 28;
        if (!NetV60_ReadI32(buf, len, &off, &x)) { return 0; }
        count = (int)x;
        if (count < 0 || count > 2048) { return -1; }
        if (off + count * 3 > len) { return 0; }
        *consumed = off + count * 3;
        return 1;
    case 61:
        /* Packet61DoorChange: int effectId, int x, byte y, int z, int aux = 17 bytes.
           The Java packet reports 20 in the decompile, but the actual read path is 17;
           keep the stream aligned to the read path and never execute the effect locally. */
        if (off + 17 > len) { return 0; }
        *consumed = off + 17;
        return 1;
    case 70:
        if (off + 1 > len) { return 0; }
        *consumed = off + 1;
        return 1;
    case 71:
        if (off + 17 > len) { return 0; }
        *consumed = off + 17;
        return 1;
    case 100:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        b = NetV80_ToSignedByte(b);
        if (!NetV60_ReadU8(buf, len, &off, &type)) { return 0; }
        rc = NetV80_ReadUTF8String(buf, len, &off, 128, text, sizeof(text));
        if (rc <= 0) { return rc; }
        if (!NetV60_ReadU8(buf, len, &off, &count)) { return 0; }
        NetV80_OpenWindow(b, type, text, count);
        *consumed = off;
        return 1;
    case 101:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        NetV80_CloseWindow(NetV80_ToSignedByte(b));
        *consumed = off;
        return 1;
    case 103:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        b = NetV80_ToSignedByte(b);
        if (!NetV60_ReadI16(buf, len, &off, &side)) { return 0; }
        rc = NetV80_ReadItemStack(buf, len, &off, &stack);
        if (rc <= 0) { return rc; }
        NetV80_SetWindowSlot(b, side, &stack);
        *consumed = off;
        return 1;
    case 104:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        b = NetV80_ToSignedByte(b);
        if (!NetV60_ReadI16(buf, len, &off, &count)) { return 0; }
        if (count < 0 || count > 256) { return -1; }
        for (i = 0; i < count; i++) {
            rc = NetV80_ReadItemStack(buf, len, &off, &stack);
            if (rc <= 0) { return rc; }
            NetV80_SetWindowSlot(b, i, &stack);
        }
        *consumed = off;
        return 1;
    case 105:
        if (off + 5 > len) { return 0; }
        *consumed = off + 5;
        return 1;
    case 106:
        if (!NetV60_ReadU8(buf, len, &off, &b)) { return 0; }
        b = NetV80_ToSignedByte(b);
        if (!NetV60_ReadI16(buf, len, &off, &side)) { return 0; }
        if (!NetV60_ReadU8(buf, len, &off, &b2)) { return 0; }
        if (!b2) {
            NetV80_SendTransaction(b, side, 1);
        }
        *consumed = off;
        return 1;
    case 130:
        if (off + 10 > len) { return 0; }
        off += 10;
        for (i = 0; i < 4; i++) {
            rc = NetV60_SkipString(buf, len, &off, 15);
            if (rc <= 0) { return rc; }
        }
        *consumed = off;
        return 1;
    case 131:
        if (off + 5 > len) { return 0; }
        off += 4;
        if (!NetV60_ReadU8(buf, len, &off, &count)) { return 0; }
        if (off + count > len) { return 0; }
        *consumed = off + count;
        return 1;
    case 200:
        if (off + 5 > len) { return 0; }
        *consumed = off + 5;
        return 1;
    case 201:
        rc = NetV60_ReadString(buf, len, &off, 64, text, sizeof(text));
        if (rc <= 0) { return rc; }
        if (off + 3 > len) { return 0; }
        *consumed = off + 3;
        return 1;
    case 250:
        rc = NetV60_ReadString(buf, len, &off, 32, text, sizeof(text));
        if (rc <= 0) { return rc; }
        if (!NetV60_ReadI16(buf, len, &off, &count)) { return 0; }
        if (count < 0 || count > 32767) { return -1; }
        if (off + count > len) { return 0; }
        *consumed = off + count;
        return 1;
    case 255:
        rc = NetV60_ReadString(buf, len, &off, 100, text, sizeof(text));
        if (rc <= 0) { return rc; }
        NetV61_SanitizeDisplayText(text);
        *consumed = off;
        NetV60_Fail(text);
        return 1;
    default:
        sprintf(text, "Unsupported or invalid server packet id %d; disconnected to protect packet sync.", op);
        NetV60_Fail(text);
        return -1;
    }
}

static void NetV60_ParseIncoming(void)
{
    int consumed;
    int rc;
    while (g_netV60ReadLen > 0) {
        if (NetV76_NetworkReadBudgetExhausted()) { return; }
        consumed = 0;
        rc = NetV60_HandlePacket(g_netV60ReadBuffer, g_netV60ReadLen, &consumed);
        if (rc == 0) { return; }
        if (rc < 0 || consumed <= 0 || consumed > g_netV60ReadLen) {
            NetV75_TracePacket("BAD", (int)g_netV60ReadBuffer[0], NetV75_PacketName((int)g_netV60ReadBuffer[0]), consumed, g_netV60ReadLen);
            if (g_netV60State != 3) { NetV60_Fail("Invalid packet stream from server."); }
            return;
        }
        NetV75_TracePacket("IN", (int)g_netV60ReadBuffer[0], NetV75_PacketName((int)g_netV60ReadBuffer[0]), consumed, g_netV60ReadLen);
        g_netV61PacketsThisTick++;
        g_netV61BytesThisTick += (long)consumed;
        if (g_netV61BytesThisTick > NETV61_MAX_BYTES_PER_TICK) {
            /* V76: a valid server can send several compressed map chunks while
               joining.  Do not treat that as an attack; stop parsing for this
               frame and finish the remaining bytes next tick. */
            NetV76_FinishDeferredRemotePost();
            return;
        }
        if (consumed < g_netV60ReadLen) {
            memmove(g_netV60ReadBuffer, g_netV60ReadBuffer + consumed, g_netV60ReadLen - consumed);
        }
        g_netV60ReadLen -= consumed;
    }
}

static void NetV60_PollRead(void)
{
    int n;
    int err;
    int loops;
    fd_set readSet;
    struct timeval tv;
    int ready;
    char status[128];
    loops = 0;
    while (g_netV60ReadLen < NETV60_READ_BUFFER_SIZE - 4096) {
        if (loops >= NETV76_MAX_RECV_LOOPS_PER_TICK) { break; }
        if (NetV76_NetworkReadBudgetExhausted()) { break; }
        loops++;
        FD_ZERO(&readSet);
        FD_SET(g_netV60Socket, &readSet);
        tv.tv_sec = 0;
        tv.tv_usec = 0;
        ready = select(0, &readSet, NULL, NULL, &tv);
        if (ready == SOCKET_ERROR) { NetV60_Fail("select() failed during network read."); return; }
        if (ready == 0) { break; }
        n = recv(g_netV60Socket, (char *)g_netV60ReadBuffer + g_netV60ReadLen, NETV60_READ_BUFFER_SIZE - g_netV60ReadLen, 0);
        if (n > 0) {
            g_netV60ReadLen += n;
            g_netV60LastReadTime = g_netV60TimeNow;
            NetV60_ParseIncoming();
            NetV76_FinishDeferredRemotePost();
            if (g_netV60State != 2) { return; }
            if (NetV76_NetworkReadBudgetExhausted()) { break; }
            continue;
        }
        if (n == 0) {
            NetV60_Fail("Server closed the connection.");
            return;
        }
        err = WSAGetLastError();
        if (err == WSAEWOULDBLOCK || err == WSAEINPROGRESS) { break; }
        sprintf(status, "Socket read failed: %d", err);
        NetV60_Fail(status);
        return;
    }
    if (g_netV60ReadLen >= NETV60_READ_BUFFER_SIZE - 4096) {
        NetV60_Fail("Network receive buffer overflow prevented.");
    }
}

static void NetV60_TickConnect(void)
{
    fd_set writeSet;
    fd_set errSet;
    struct timeval tv;
    int rc;
    int err;
    int errLen;
    if (g_netV60TimeNow - g_netV60ConnectTime > NETV60_CONNECT_TIMEOUT) {
        NetV60_Fail("Connection timed out.");
        return;
    }
    FD_ZERO(&writeSet);
    FD_ZERO(&errSet);
    FD_SET(g_netV60Socket, &writeSet);
    FD_SET(g_netV60Socket, &errSet);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    rc = select(0, NULL, &writeSet, &errSet, &tv);
    if (rc == SOCKET_ERROR) {
        NetV60_Fail("select() failed during connect.");
        return;
    }
    if (rc == 0) { return; }
    err = 0;
    errLen = sizeof(err);
    getsockopt(g_netV60Socket, SOL_SOCKET, SO_ERROR, (char *)&err, &errLen);
    if (err != 0 || FD_ISSET(g_netV60Socket, &errSet)) {
        NetV60_Fail("Could not connect to server.");
        return;
    }
    g_netV60State = 2;
    g_netV60LastReadTime = g_netV60TimeNow;
    NetV60_SetStatus("Connected. Sending Beta 1.7.3 handshake...");
    NetV62_SendInitialHandshake();
}

static void NetV60_TickPosition(double dt)
{
    double gx;
    double gy;
    double stance;
    double gz;
    double dx;
    double dy;
    double ds;
    double dz;
    double dyaw;
    double dpitch;
    int moved;
    int rotated;
    if (g_state != STATE_GAME || !g_networkMultiplayerActive || !NetworkV60_IsConnected()) { return; }
    if (NetworkV78_ShouldHoldPlayerDuringJoin()) {
        g_netV60PositionTimer += dt;
        if (g_netV60PositionTimer >= 0.25) {
            g_netV60PositionTimer = 0.0;
            NetV60_SendPacket10();
        }
        return;
    }
    g_netV60PositionTimer += dt;
    if (g_netV60PositionTimer < NETV60_POSITION_INTERVAL) { return; }
    g_netV60PositionTimer = 0.0;
    if (g_netV62ProtocolMode == NETV62_PROTOCOL_CLASSICUBE) {
        unsigned char cbuf[16];
        int coff;
        int ix;
        int iy;
        int iz;
        int cyaw;
        int cpitch;
        ix = (int)((playerX + (double)worldOriginBlockX) * 32.0);
        iy = (int)((playerY + EYE_HEIGHT) * 32.0);
        iz = (int)((playerZ + (double)worldOriginBlockZ) * 32.0);
        cyaw = ((int)(yaw * 256.0 / 360.0)) & 255;
        cpitch = ((int)(pitch * 256.0 / 360.0)) & 255;
        coff = 0;
        NetV60_WriteU8(cbuf, &coff, 8);
        NetV60_WriteU8(cbuf, &coff, 0xff);
        NetV60_WriteU16(cbuf, &coff, ix & 0xffff);
        NetV60_WriteU16(cbuf, &coff, iy & 0xffff);
        NetV60_WriteU16(cbuf, &coff, iz & 0xffff);
        NetV60_WriteU8(cbuf, &coff, cyaw);
        NetV60_WriteU8(cbuf, &coff, cpitch);
        NetV60_SendRaw(cbuf, coff);
        return;
    }
    gx = playerX + (double)worldOriginBlockX;
    gy = playerY;
    stance = playerY + EYE_HEIGHT;
    gz = playerZ + (double)worldOriginBlockZ;
    dx = fabs(gx - g_netV60OldX);
    dy = fabs(gy - g_netV60OldY);
    ds = fabs(stance - g_netV60OldStance);
    dz = fabs(gz - g_netV60OldZ);
    dyaw = fabs((double)((float)yaw - g_netV60OldYaw));
    dpitch = fabs((double)((float)pitch - g_netV60OldPitch));
    moved = (dx > 0.0001 || dy > 0.0001 || ds > 0.0001 || dz > 0.0001 || g_netV60OldGround != onGround);
    rotated = (dyaw > 0.0001 || dpitch > 0.0001);
    if (moved && rotated) { NetV60_SendPacket13(gx, gy, stance, gz, (float)yaw, (float)pitch); }
    else if (moved) { NetV60_SendPacket11(gx, gy, stance, gz); }
    else if (rotated) { NetV60_SendPacket12((float)yaw, (float)pitch); }
    else { NetV60_SendPacket10(); }
    if (moved) {
        g_netV60OldX = gx;
        g_netV60OldY = gy;
        g_netV60OldStance = stance;
        g_netV60OldZ = gz;
        g_netV60OldGround = onGround;
    }
    if (rotated) {
        g_netV60OldYaw = (float)yaw;
        g_netV60OldPitch = (float)pitch;
    }
}

void NetworkV60_Tick(double dt)
{
    g_netV60TimeNow = NetV60_TimeSeconds();
    NetV61_ResetTickBudget();
    if (g_netV60State == 1) { NetV60_TickConnect(); }
    if (g_netV60State == 2) {
        NetV60_PollRead();
        NetV76_FinishDeferredRemotePost();
        NetV77_CheckJoinHoldRelease();
        if (g_netV60State == 2 && g_netV60TimeNow - g_netV60LastReadTime > NETV60_READ_TIMEOUT) {
            NetV60_Fail("Connection timed out waiting for server packets.");
        }
        if (g_netV60State == 2) { NetV60_TickPosition(dt); }
    }
}

void NetworkV62_BeginConnectEx(const char *address, const char *username, int protocolMode)
{
    struct hostent *hostEntry;
    struct sockaddr_in addr;
    unsigned long nonblock;
    unsigned long rawAddr;
    int rc;
    int err;
    char status[256];
    NetworkV62_SetUsername(username);
    NetworkV62_SetProtocolMode(protocolMode);
    if (!NetV60_WinsockInit()) { return; }
    NetworkV60_Disconnect("Starting new connection.");
    if (!NetV60_ParseAddress(address, g_netV60Host, sizeof(g_netV60Host), &g_netV60Port)) {
        NetV60_Fail("Invalid server address. Use host or host:port.");
        return;
    }
    g_netV60Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (g_netV60Socket == INVALID_SOCKET) {
        NetV60_Fail("Could not create TCP socket.");
        return;
    }
    NetV61_ConfigureSocket(g_netV60Socket);
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons((unsigned short)g_netV60Port);
    rawAddr = inet_addr(g_netV60Host);
    if (rawAddr == INADDR_NONE) {
        hostEntry = gethostbyname(g_netV60Host);
        if (!hostEntry || !hostEntry->h_addr_list || !hostEntry->h_addr_list[0]) {
            NetV60_Fail("Unknown host.");
            return;
        }
        memcpy(&addr.sin_addr, hostEntry->h_addr_list[0], 4);
    } else {
        addr.sin_addr.s_addr = rawAddr;
    }
    nonblock = 1;
    ioctlsocket(g_netV60Socket, FIONBIO, &nonblock);
    rc = connect(g_netV60Socket, (struct sockaddr *)&addr, sizeof(addr));
    if (rc == 0) {
        g_netV60State = 2;
        g_netV60ConnectTime = NetV60_TimeSeconds();
        g_netV60LastReadTime = g_netV60ConnectTime;
        g_netV61LastChatTime = -9999.0;
        g_netV61ChatWindowStart = g_netV60ConnectTime;
        g_netV61ChatBurstCount = 0;
        NetV60_SetStatus("Connected. Sending Beta 1.7.3 handshake...");
        NetV62_SendInitialHandshake();
        return;
    }
    err = WSAGetLastError();
    if (err != WSAEWOULDBLOCK && err != WSAEINPROGRESS && err != WSAEINVAL) {
        sprintf(status, "Connection failed: Winsock error %d", err);
        NetV60_Fail(status);
        return;
    }
    g_netV60State = 1;
    g_netV60ConnectTime = NetV60_TimeSeconds();
    g_netV60LastReadTime = g_netV60ConnectTime;
    g_netV60ReadLen = 0;
    g_netV60OldX = 999999.0;
    g_netV60OldY = 999999.0;
    g_netV60OldStance = 999999.0;
    g_netV60OldZ = 999999.0;
    g_netV60OldYaw = 999999.0f;
    g_netV60OldPitch = 999999.0f;
    g_netV60OldGround = -1;
    g_netV61LastChatTime = -9999.0;
    g_netV61ChatWindowStart = g_netV60ConnectTime;
    g_netV61ChatBurstCount = 0;
    sprintf(status, "Connecting to %s:%d...", g_netV60Host, g_netV60Port);
    NetV60_SetStatus(status);
}

void NetworkV60_BeginConnect(const char *address)
{
    NetworkV62_BeginConnectEx(address, NetworkV62_GetUsername(), g_netV62ProtocolMode);
}
