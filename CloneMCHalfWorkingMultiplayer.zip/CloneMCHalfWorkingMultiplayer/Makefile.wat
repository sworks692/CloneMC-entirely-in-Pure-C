# CloneMC V81 Open Watcom Win32 build
# Build from the project root with: wmake -f Makefile.wat

EXE = CloneMC_V81_FontTextureCompat.exe
SRC = project2finalalpharecreation.c
LNK = clonemc_v81_nt_win.lnk

$(EXE): $(SRC) $(LNK)
	wcl386 -q -bt=nt -l=nt_win -fe=$(EXE) @$(LNK) $(SRC)

clean: .SYMBOLIC
	@if exist $(EXE) del $(EXE)
