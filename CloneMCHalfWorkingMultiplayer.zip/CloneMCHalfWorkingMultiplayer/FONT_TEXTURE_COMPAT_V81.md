CloneMC V81 Font + Server Texture Compatibility
==============================================

Scope
-----
V81 is a focused patch on top of V80. It does not rewrite networking. It fixes
old-Windows font visibility and makes server terrain texture lookup safer and
more Java/Beta compatible.

1. Font visibility on Windows 2000
----------------------------------
Previous behavior:
- DrawText2D always used Win32/GDI OpenGL display-list glyphs from
  wglUseFontBitmaps.
- On some Windows 2000/OpenGL 1.1 systems, those lists can fail or be empty,
  making menus/chat/HUD text invisible.

V81 behavior:
- CreateFonts records whether wglUseFontBitmaps succeeded.
- DrawText2D falls back to the renderer-owned Beta bitmap font when it is
  loaded.
- If the texture font is also unavailable, DrawText2D falls back to the built-in
  immediate-mode 5x7 block font.
- This keeps text visible even when GDI font display lists fail.

Patched file:
    src/60_ui/clonemc_platform_ui_resources.c

2. Server terrain texture atlas
-------------------------------
Previous behavior:
- Runtime terrain used the 512x256 uploaded terrain.tga/terrain_v58_canonical.tga.
- Mapping server block IDs to that custom 32-column atlas required a manual
  Java-index-to-atlas table.
- Some older Windows 2000-era OpenGL drivers can reject 512-wide textures, which
  causes white or wrong-textured blocks.

V81 behavior:
- Adds a generated 256x256 atlas:
      assets/terrain_server_java16.tga
      assets/terrain_server_java16.png
- This atlas is built from the uploaded terrain.png and packed by Java terrain
  index:
      col = index & 15
      row = index >> 4
- ResourceV58_LoadTerrainTexture tries this 256x256 Java-index atlas first.
- Terrain UV math now uses runtime atlas dimensions instead of hard-coded
  512x256 values.

Patched files:
    src/00_core/clonemc_core_defs.c
    src/60_ui/clonemc_platform_ui_resources.c
    src/20_entity/clonemc_entity_items_player_physics.c
    src/30_item/clonemc_items_containers_redstone.c
    src/40_world/clonemc_world_generation_streaming.c

3. Flowing water server block ID
--------------------------------
Beta servers can send water as both block ID 8 and block ID 9. Older CloneMC
only registered block ID 9 as water. V81 adds:

    BLOCK_FLOWING_WATER = 8
    BLOCK_WATER = 9

and registers both with the fluid renderer/material/layer flags. This prevents
server terrain water from rendering as the wrong/unknown block.

Patched files:
    src/00_core/clonemc_core_defs.c
    src/60_ui/clonemc_platform_ui_resources.c
    src/70_render/clonemc_render_block_types.c

4. Build files
--------------
Current V81 output:
    CloneMC_V81_FontTextureCompat.exe

Current build files:
    Makefile.wat
    clonemc_v81_nt_win.lnk
    BUILD_WIN32_OPENWATCOM.bat
    RUN_WITH_NET_TRACE.bat

