@echo off
rem CloneMC V81 Open Watcom build helper.
rem Set WATCOM/PATH/INCLUDE/LIB first if Open Watcom is not already in PATH.

if exist CloneMC_V81_FontTextureCompat.exe del CloneMC_V81_FontTextureCompat.exe
wmake -f Makefile.wat
