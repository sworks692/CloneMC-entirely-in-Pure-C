CloneMC V81 Font + Texture Compatibility Source
==============================================

This V81 package is based on V80 and focuses on two issues:

1. Font/text not showing on Windows 2000 systems.
2. Server terrain showing wrong or missing block textures after terrain loading
   started working.

Build
-----
Use Open Watcom from this folder:

    wmake -f Makefile.wat

or run:

    BUILD_WIN32_OPENWATCOM.bat

Output:

    CloneMC_V81_FontTextureCompat.exe

Debug run:

    RUN_WITH_NET_TRACE.bat

Important files
---------------

    project2finalalpharecreation.c
    src/
    assets/terrain_server_java16.tga
    assets/terrain_server_java16.png
    Makefile.wat
    clonemc_v81_nt_win.lnk
    FONT_TEXTURE_COMPAT_V81.md
    V81_PATCH_SUMMARY.txt

Notes
-----
The new terrain_server_java16 atlas is generated from the uploaded terrain.png.
It is not downloaded from an online Minecraft asset source. It is packed by Java
terrain index so Beta server block textures map directly and it remains 256x256
for better Windows 2000/OpenGL 1.1 compatibility.

The source is still an Open Watcom unity build. Compile the root C file only.
