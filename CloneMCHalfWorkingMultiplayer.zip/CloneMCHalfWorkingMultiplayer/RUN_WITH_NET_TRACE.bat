@echo off
rem Enables packet trace logging for debugging Beta 1.7.3 multiplayer sync.
type nul > net_trace_enable.txt
if exist net_trace.txt del net_trace.txt
CloneMC_V81_FontTextureCompat.exe
